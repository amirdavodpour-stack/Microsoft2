# HOPE Marketplace

A two-sided work marketplace: buyers post jobs, providers submit offers,
and a payment-hold/release flow settles the job once evidence is accepted.

- `backend/` — Node.js HTTP API (no framework), PostgreSQL-backed in
  production, JSON-file-backed for local development. See
  `backend/README.md`.
- `lib/` — Flutter mobile client (RTL, Material 3).
- `android/` — Android build configuration for the Flutter app.
- `test/`, `integration_test/` — Flutter unit/widget/integration tests.
- `tools/` — release helper scripts (`build_apk_release.sh`,
  `static_audit.sh`).
- `backend/data/` — local JSON datastore used by the backend when `DATABASE_URL`
  is not set.

## What's implemented

**Backend routes** (`backend/src/app.js`): auth (register, login, logout,
refresh, password-reset request/confirm), provider profile, categories,
jobs (create, publish, list, detail, "mine"), offers (create, accept),
job execution transitions (start, deliver, accept-delivery, evidence),
payments (fund, release, status), and file upload (multipart, presigned
S3, and completion-verified direct upload).

**Mobile app** (`lib/`): guest browsing, login/register/password reset,
job listing/detail/create, offers, the full transaction lifecycle UI
(fund → start → evidence → deliver → accept → settlement), profile,
secure token storage with automatic access-token refresh, and an upload
retry queue.

There is no separate web client in this repository. The current release
scope is the Flutter mobile client plus the hardened API and its protected
admin/operations surfaces.

## Not implemented / known limitations

- **Payments are simulated.** `PAYMENT_PROVIDER=simulator` is the only
  supported provider (`backend/src/payment_provider.js`); no real money
  moves. A real payment-service-provider adapter is required before this
  can process live transactions. Production configuration rejects the
  simulator.
- **External notifications are provider-bound but not bundled.** Push and
  email delivery require configured HTTPS provider endpoints; in-app
  notifications work without them. A real FCM/APNs registration layer is not
  included yet.
- **Observability is currently first-party and in-process.** Funnel metrics,
  crash/error ingestion and health telemetry exist, but centralized metrics,
  external alert delivery and distributed tracing still require deployment
  integrations.
- **External operations integrations remain environment-dependent.** Real PSP,
  FCM/APNs, email and S3 end-to-end validation must be completed in staging.

## Repository layout

- `backend/` — API, persistence, workers, migrations, and backend tests.
- `lib/`, `test/`, `integration_test/`, `android/` — Flutter client and Android runtime.
- `tools/` — local validation, staging, release, and certification utilities.
- `.github/workflows/` — CI, security, Wave 8, staging, device, DR, and production release gates.
- `docs/` — current technical references.

## Quick start

Backend:

```bash
cd backend
cp .env.example .env
node src/migrate.js
node src/server.js
```

Mobile app, pointed at a local backend on an Android emulator:

```bash
flutter pub get
flutter run --dart-define=API_BASE_URL=http://10.0.2.2:3000/api/v1
```

Release APK:

```bash
flutter build apk --release --dart-define=API_BASE_URL=https://YOUR_API_HOST/api/v1
```

Build/signing details, including the Flutter/Android toolchain versions
this repo targets, are in `android/ANDROID-CONFIG.md`,
`android/README-API-CONFIG.md`, and `tools/build_apk_release.sh`.
Production release signing is intentionally fail-closed: this repository
does not contain a production keystore, and pilot/local builds made with
a non-production keystore must never be treated as store-ready
artifacts.

## Architecture

The backend keeps `app.js` as the HTTP composition root while cross-cutting validation and session policy live in dedicated modules under `backend/src/policies/` and `backend/src/services/`. PostgreSQL row-to-domain mapping is isolated in `backend/src/repository/mappers.js`; this keeps SQL orchestration separate from API/domain shape conversion and creates explicit seams for the next decomposition waves.

## Project history

See `CHANGELOG.md` for the condensed product history. Operational references: `SECURITY-THREAT-MODEL.md`, `AUTHORIZATION-MATRIX.md`, `DISASTER-RECOVERY.md`, and `RELEASE-CHECKLIST.md`.

## CI / GitHub Actions

The repository is ready to be placed directly in GitHub. Workflows are pinned to immutable action SHAs and use least-privilege repository permissions.

- `main.yml` — backend checks, Flutter analysis/tests, Android build, APK artifact.
- `wave8-certification.yml` — independent fail-closed product-grade certification gates with checkpointed evidence.
- `codeql.yml`, `dependency-review.yml`, `scorecard.yml` — supply-chain and security automation.
- `staging-certification.yml`, `staging-resilience.yml`, `device-integration.yml`, `dr-restore.yml` — runtime certification when the required staging infrastructure and secrets are configured.
- `production-release.yml` — manually confirmed production release; requires successful staging certification and production signing secrets.

Required repository/environment secrets vary by workflow. The repository intentionally contains no production credentials or signing keys.

For the normal APK workflow, configure `API_BASE_URL` as a repository secret or variable pointing to a real HTTPS staging API. Production release additionally requires the documented staging, production, and Android signing secrets used by `production-release.yml`.

## Financial engine
HOPE now exposes a transactional financial model around each payment. The advertised amount is the economic base; the API returns the employer charge, platform fee and provider payout explicitly. Mission fees are 10% on the employer side and 10% on the worker side. Job fees are 30% of the first-month salary on the employer side. A double-entry style ledger, settlement record, refund lifecycle and signed webhook boundary are included. The bundled payment provider is still a simulator; a production PSP adapter must implement the provider boundary without bypassing the ledger/state machine.


## Notification & Event System

HOPE now has durable in-app notifications backed by the outbox. Push and email delivery are configurable through `NOTIFICATION_PUSH_URL` and `NOTIFICATION_EMAIL_URL`; when those providers are not configured, in-app notifications still work and external delivery is recorded as not configured rather than silently failing.

## Wave 4 — Privacy & Recommendation Quality

Wave 4 adds production-oriented privacy controls and recommendation quality safeguards.

### Account privacy API
- `GET /api/v1/account/export` — authenticated data export containing the account, provider, jobs, applications, offers, payments (credential fields removed), notifications and preferences.
- `POST /api/v1/account/delete` — authenticated irreversible privacy deletion. Requires JSON `{ "confirmation": "DELETE" }`. Authentication/session material and analytics/crash telemetry are removed; the account is anonymized and marked `DELETED`. Financially relevant records are preserved where referential integrity requires them.

### Telemetry consent
Mobile telemetry is now opt-in by default. The Flutter telemetry service exposes `telemetryConsent` and `setTelemetryConsent(bool)`; disabling consent also removes the local anonymous telemetry identifier.

### Recommendation quality
Recommendation scoring now applies freshness decay and category diversity penalties while preserving the existing eight public component scores and API shape. Ranking is deterministic after score ties.

## GitHub ZIP-only bootstrap

This repository is designed for environments where the project can only be uploaded as a ZIP. GitHub does not execute workflows stored inside a ZIP until the ZIP has been extracted into repository files.

One-time bootstrap:
1. Upload `HOPE-3_8_0-GITHUB-READY.zip` to the repository root.
2. Create the single file `.github/workflows/zip-bootstrap.yml` from the matching file in this package.
3. Open **Actions → HOPE ZIP Bootstrap → Run workflow**.

The bootstrap safely extracts the archive, discovers the Flutter project root, removes the uploaded ZIP, resolves and commits `pubspec.lock`, and pushes the normalized project. That push automatically starts **HOPE ZIP Build, Test, Diagnose and APK**.

The build workflow runs deterministic backend/static tests, Flutter analysis/tests, localization and Android/Gradle structural checks, then builds debug and pilot release APKs independently of earlier test failures. Every phase writes logs and a machine-readable result; artifacts are uploaded even when a test fails. The workflow exits red after artifacts are preserved when any phase fails.

For a real staging runtime, set repository secret `API_BASE_URL_STAGING`. Without it, the pilot build uses the non-production CI placeholder `https://ci.invalid/api/v1` so an installable pilot artifact can still be built without pretending it is a live deployment.
