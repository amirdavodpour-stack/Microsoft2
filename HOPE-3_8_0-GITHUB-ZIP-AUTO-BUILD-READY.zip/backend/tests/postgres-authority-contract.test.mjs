import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const read = (p) => fs.readFileSync(new URL(`../${p}`, import.meta.url), 'utf8');

test('analytics and notifications use repository writes in PostgreSQL mode', () => {
  const analytics = read('src/analytics.js');
  const notifications = read('src/notifications.js');
  assert.match(analytics, /if\s*\(process\.env\.DATABASE_URL\)\s*return\s+repo\.insertAnalyticsEvent/);
  assert.match(analytics, /if\s*\(process\.env\.DATABASE_URL\)\s*return\s+repo\.insertCrashReport/);
  assert.match(notifications, /if\s*\(process\.env\.DATABASE_URL\)\s*\{\s*return\s+repo\.queueNotification/);
});

test('runtime user lookup is PostgreSQL-authoritative', () => {
  const app = fs.readFileSync(new URL('../../backend/src/app.js', import.meta.url), 'utf8');
  assert.match(app, /const findUser = \(id\) => process\.env\.DATABASE_URL \? repo\.findUserById\(id\) : db\.collection\.users\.find/);
});

test('job offer listing is PostgreSQL-authoritative', () => {
  const jobs = fs.readFileSync(new URL('../../backend/src/routes/job_handlers.js', import.meta.url), 'utf8');
  assert.match(jobs, /const offerRows = process\.env\.DATABASE_URL \? await repo\.listOffersForJob\(job\.id\) : db\.collection\.offers\.filter/);
});

test('PostgreSQL pool has server-side statement and lock timeouts', () => {
  const db = fs.readFileSync(new URL('../../backend/src/db.js', import.meta.url), 'utf8');
  assert.match(db, /statement_timeout:/);
  assert.match(db, /lock_timeout:/);
});
