import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../..');

const read = (relative) => fs.readFileSync(path.join(root, relative), 'utf8');

test('Wave 0 release documentation matches the repository state', () => {
  const readme = read('README.md');
  const checklist = read('RELEASE-CHECKLIST.md');

  assert.match(readme, /\.github\/workflows\/main\.yml/);
  assert.match(readme, /\.github\/workflows\/production-release\.yml/);
  assert.doesNotMatch(readme, /intentionally contains no `\.github\/workflows` build pipeline/i);
  assert.match(readme, /Payments are simulated/i);
  assert.match(readme, /Observability is currently first-party and in-process/i);
  assert.match(readme, /centralized metrics,\s*external alert delivery and distributed tracing/i);

  assert.match(checklist, /^# HOPE 3\.8\.0 Release Checklist/m);
  assert.match(checklist, /## Wave 0 engineering baseline/);
  assert.match(checklist, /Real PSP adapter and sandbox verification/);
  assert.match(checklist, /Physical Android device QA/);
});
