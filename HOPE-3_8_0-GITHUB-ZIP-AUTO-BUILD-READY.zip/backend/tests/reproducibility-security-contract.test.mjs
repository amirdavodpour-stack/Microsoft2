import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const config = fs.readFileSync(new URL('../src/config.js', import.meta.url), 'utf8');
const notifications = fs.readFileSync(new URL('../src/routes/notification_routes.js', import.meta.url), 'utf8');
const perf = fs.readFileSync(new URL('../tools/perf-smoke.mjs', import.meta.url), 'utf8');
test('release hardening contracts remain explicit', () => {
  assert.match(config, /randomBytes\(48\)/);
  assert.match(notifications, /includeToken: false/);
  assert.match(perf, /PERF_MAX_RUNTIME_MS/);
  assert.match(perf, /AbortSignal\.timeout/);
});
