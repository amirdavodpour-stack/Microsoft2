import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../..');
const read = (p) => fs.readFileSync(path.join(root, p), 'utf8');

test('OpenAPI contains security and responses for high-risk documented routes', () => {
  const spec = read('backend/openapi/openapi.yaml');
  for (const route of ['/account/export:', '/account/delete:', '/analytics/admin/crashes:', '/providers/me/verification:', '/jobs/{id}/reviews:', '/jobs/{id}/dispute:', '/jobs/{id}/rework:', '/jobs/{id}/cancel:', '/payments/financials/{jobId}:', '/payments/refund/{jobId}:']) {
    const i = spec.indexOf(`\n  ${route}`);
    assert.ok(i >= 0, `Missing OpenAPI route ${route}`);
    const block = spec.slice(i, spec.indexOf('\n  /', i + 3) === -1 ? spec.length : spec.indexOf('\n  /', i + 3));
    assert.match(block, /security:/, `Missing security requirement for ${route}`);
    assert.match(block, /responses:/, `Missing response schema for ${route}`);
  }
});


test('every OpenAPI path placeholder has a required path parameter definition', () => {
  const spec = read('backend/openapi/openapi.yaml');
  const pathBlocks = spec.split(/\n  (?=\/)/).filter(Boolean);
  for (const block of pathBlocks) {
    const route = block.match(/^\s*(\/[^\n:]+):/m)?.[1];
    if (!route) continue;
    const placeholders = [...route.matchAll(/\{([^}]+)\}/g)].map((m) => m[1]);
    for (const name of placeholders) {
      const inline = new RegExp(`name:\\s*${name}\\b[^\\n]*in:\\s*path[^\\n]*required:\\s*true`).test(block);
      const multiline = new RegExp(`name:\\s*${name}\\s*\\n\\s*in:\\s*path\\s*\\n\\s*required:\\s*true`).test(block);
      assert.ok(inline || multiline, `${route} is missing required path parameter ${name}`);
    }
  }
});
