import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';

const root = path.resolve(new URL('..', import.meta.url).pathname, '..');
const read = (p) => fs.readFileSync(path.join(root, p), 'utf8');

test('storage completion binds object size to upload intent and global max', () => {
  const routes = read('backend/src/routes/storage_routes.js');
  const schema = read('backend/src/db/schema.js');
  const repo = read('backend/src/repository/storage.js');
  assert.match(schema, /expected_size INTEGER/);
  assert.match(routes, /intent\.expectedSize/);
  assert.match(routes, /UPLOAD_SIZE_MISMATCH/);
  assert.match(routes, /head\.size <= 0 \|\| head\.size > config\.maxUploadBytes/);
  assert.match(routes, /config\.maxUploadBytes/);
  assert.match(repo, /expected_size/);
});

test('notification dispatch has a durable delivery ledger and terminal diagnostics', () => {
  const schema = read('backend/src/db/schema.js');
  const repo = read('backend/src/repository/notifications.js');
  const handlers = read('backend/src/outbox_handlers.js');
  const serialization = read('backend/src/db/serialization.js');
  assert.match(schema, /CREATE TABLE IF NOT EXISTS notification_deliveries/);
  assert.match(schema, /UNIQUE\(notification_id,channel\)/);
  assert.match(repo, /markNotificationDeliveryDelivered/);
  assert.match(repo, /markNotificationDeliveryFailed/);
  assert.match(handlers, /Boolean\(failed\?\.terminal\)/);
  assert.match(serialization, /notificationDeliveries/);
});

test('mobile upload queue persists items and API client retries only GETs', () => {
  const queue = read('lib/core/uploads/upload_queue.dart');
  const api = read('lib/core/network/api_client.dart');
  assert.match(queue, /hope\.upload_queue\.v2/);
  assert.match(queue, /SharedPreferences/);
  assert.match(queue, /await _persist\(\)/);
  assert.match(api, /final retryableMethod = upper == 'GET'/);
  assert.match(api, /retryableMethod \? 3 : 1/);
});

test('backup tooling produces and verifies a SHA-256 sidecar', () => {
  const backup = read('backend/scripts/backup.sh');
  const verify = read('backend/scripts/verify-backup.sh');
  assert.match(backup, /sha256sum .*\.dump/);
  assert.match(verify, /Backup checksum verification failed/);
});

