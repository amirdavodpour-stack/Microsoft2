import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const read = (p) => fs.readFileSync(new URL(p, import.meta.url), 'utf8');

test('mobile recommendations minimize precise location before transmission', () => {
  const source = read('../../lib/features/jobs/jobs_page.dart');
  assert.match(source, /toStringAsFixed\(2\)/);
  assert.match(source, /kilometre-scale precision/);
});

test('Android disables backup and declares RTL support', () => {
  const manifest = read('../../android/app/src/main/AndroidManifest.xml');
  assert.match(manifest, /android:allowBackup=\"false\"/);
  assert.match(manifest, /android:supportsRtl=\"true\"/);
});

test('authentication has both IP and account-scoped throttling', () => {
  const limiter = read('../src/rate_limit.js');
  const auth = read('../src/routes/auth_routes.js');
  assert.match(limiter, /authIdentity/);
  assert.match(auth, /rateLimitAuthIdentity/);
  assert.match(auth, /config\.authIdentityRateLimitMax/);
});
