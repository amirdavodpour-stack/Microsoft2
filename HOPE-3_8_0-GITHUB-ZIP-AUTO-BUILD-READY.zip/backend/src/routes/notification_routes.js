import { URL } from 'node:url';

/**
 * Notification HTTP routes; dependencies are injected by the composition root.
 */
export function createNotificationRoutes({ authUser, db, repo, readBody, sendJson, HttpError, requireFields, enumField, textField, now }) {
  function localNotificationPreferences(userId) {
    let p = db.collection.notificationPreferences.find(x => x.userId === userId);
    if (!p) {
      p = db.insert('notificationPreferences', {
        id: db.id(), userId, inApp: true, push: true, email: true,
        jobAlerts: true, applicationUpdates: true, paymentUpdates: true,
        marketing: false, updatedAt: now(),
      });
      db.touch('notificationPreferences');
    }
    return p;
  }

  async function notificationRoutes(req, res, parts) {
    const me = await authUser(req);
    if (req.method === 'GET' && parts.length === 1) {
      const limit = Math.min(Math.max(Number(new URL(req.url, `http://${req.headers.host || 'localhost'}`).searchParams.get('limit') || 50), 1), 100);
      const offset = Math.max(Number(new URL(req.url, `http://${req.headers.host || 'localhost'}`).searchParams.get('offset') || 0), 0);
      if (process.env.DATABASE_URL) {
        const items = await repo.listNotifications(me.id, limit, offset);
        return sendJson(res, 200, { items, unreadCount: await repo.countUnreadNotifications(me.id) });
      }
      const items = db.collection.notifications.filter(n => n.userId === me.id).sort((a,b)=>String(b.createdAt).localeCompare(String(a.createdAt))).slice(offset, offset+limit);
      return sendJson(res, 200, { items, unreadCount: db.collection.notifications.filter(n=>n.userId===me.id && !n.readAt).length });
    }
    if (req.method === 'POST' && parts[1] && parts[2] === 'read') {
      let item = null;
      if (process.env.DATABASE_URL) item = await repo.markNotificationRead(parts[1], me.id);
      else { const n=db.collection.notifications.find(x=>x.id===parts[1]&&x.userId===me.id); if(n){n.readAt=now();db.touch('notifications');await db.save();item=n;} }
      if (!item) throw new HttpError(404, 'NOTIFICATION_NOT_FOUND', 'Notification not found');
      return sendJson(res, 200, item);
    }
    if (req.method === 'POST' && parts[1] === 'read-all') {
      if (process.env.DATABASE_URL) return sendJson(res, 200, await repo.markAllNotificationsRead(me.id));
      const items=db.collection.notifications.filter(n=>n.userId===me.id&&!n.readAt); for(const n of items)n.readAt=now(); if(items.length){db.touch('notifications');await db.save();} return sendJson(res,200,{updated:items.length});
    }
    if (req.method === 'GET' && parts[1] === 'preferences') {
      if (process.env.DATABASE_URL) return sendJson(res, 200, await repo.getNotificationPreferences(me.id));
      return sendJson(res, 200, localNotificationPreferences(me.id));
    }
    if (req.method === 'PUT' && parts[1] === 'preferences') {
      const body=await readBody(req); const patch={}; for(const key of ['inApp','push','email','jobAlerts','applicationUpdates','paymentUpdates','marketing']) if(key in body) patch[key]=Boolean(body[key]);
      if (!Object.keys(patch).length) throw new HttpError(400,'INVALID_PREFERENCES','At least one preference is required');
      if (process.env.DATABASE_URL) return sendJson(res,200,await repo.updateNotificationPreferences(me.id,patch));
      const p=localNotificationPreferences(me.id); Object.assign(p,patch,{updatedAt:now()}); db.touch('notificationPreferences'); await db.save(); return sendJson(res,200,p);
    }
    if (req.method === 'POST' && parts[1] === 'devices') {
      const body=await readBody(req); requireFields(body,['platform','token']);
      const platform=enumField(body.platform,new Set(['ANDROID','IOS','WEB']),'platform'); const token=textField(body.token,'token',{min:10,max:2048,required:true});
      if(process.env.DATABASE_URL) { const device=await repo.registerNotificationDevice({id:db.id(),userId:me.id,platform,token,enabled:true}); const {token:_,...safe}=device; return sendJson(res,200,safe); }
      let d=db.collection.notificationDevices.find(x=>x.token===token); if(d){d.userId=me.id;d.platform=platform;d.enabled=true;d.updatedAt=now();} else d=db.insert('notificationDevices',{id:db.id(),userId:me.id,platform,token,enabled:true,createdAt:now(),updatedAt:now()}); db.touch('notificationDevices'); await db.save(); const {token:_,...safe}=d; return sendJson(res,200,safe);
    }
    if (req.method === 'GET' && parts[1] === 'devices') {
      if (process.env.DATABASE_URL) return sendJson(res,200,{items:await repo.listNotificationDevices(me.id, { includeToken: false })});
      return sendJson(res,200,{items:db.collection.notificationDevices.filter(x=>x.userId===me.id && x.enabled).sort((a,b)=>String(b.updatedAt).localeCompare(String(a.updatedAt))).map(({token,...device})=>device)});
    }
    if (req.method === 'DELETE' && parts[1] === 'devices' && parts[2]) {
      if (process.env.DATABASE_URL) {
        const device=await repo.disableNotificationDevice(parts[2],me.id);
        if(!device) throw new HttpError(404,'NOTIFICATION_DEVICE_NOT_FOUND','Notification device not found');
        return sendJson(res,200,{disabled:true,id:device.id});
      }
      const device=db.collection.notificationDevices.find(x=>x.id===parts[2] && x.userId===me.id);
      if(!device) throw new HttpError(404,'NOTIFICATION_DEVICE_NOT_FOUND','Notification device not found');
      device.enabled=false; device.updatedAt=now(); db.touch('notificationDevices'); await db.save();
      return sendJson(res,200,{disabled:true,id:device.id});
    }
    throw new HttpError(404,'NOT_FOUND','Notification route not found');
  }

  return notificationRoutes;
}
