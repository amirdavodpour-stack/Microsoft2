export function createAccountRoutes({ authUser, readBody, sendJson, HttpError, hashPassword, db, repo, now, findUser, anonymizedEmail, deletionCredential, buildDataExport }) {
  return async function accountRoutes(req, res, parts) {
    const me = await authUser(req);
    if (req.method === 'GET' && parts[0] === 'export') {
      const bundle = process.env.DATABASE_URL ? await repo.getUserPrivacyBundle(me.id) : {
        user: me,
        provider: db.collection.providers.find(x => x.userId === me.id) || null,
        jobs: db.collection.jobs.filter(x => x.ownerId === me.id || x.providerId === me.id),
        evidence: db.collection.evidence.filter(x => x.submittedBy === me.id),
        uploads: db.collection.uploads.filter(x => x.uploadedBy === me.id),
        applications: db.collection.jobApplications.filter(x => x.candidateId === me.id),
        offers: db.collection.offers.filter(x => x.providerId === me.id),
        payments: db.collection.payments.filter(x => x.payerId === me.id || x.payeeId === me.id),
        notifications: db.collection.notifications.filter(x => x.userId === me.id),
        preferences: db.collection.notificationPreferences.find(x => x.userId === me.id) || null,
        analyticsEvents: db.collection.analyticsEvents.filter(x => x.userId === me.id),
        crashReports: db.collection.crashReports.filter(x => x.userId === me.id),
        trustReports: db.collection.trustReports.filter(x => x.reporterId === me.id),
      };
      if (!bundle) throw new HttpError(404,'USER_NOT_FOUND','User not found');
      return sendJson(res,200,buildDataExport(bundle));
    }
    if (req.method === 'POST' && parts[0] === 'delete') {
      const body = await readBody(req);
      if (String(body?.confirmation || '').toUpperCase() !== 'DELETE') throw new HttpError(400,'CONFIRMATION_REQUIRED','Type DELETE to confirm account deletion');
      const replacement = { email: anonymizedEmail(me.id), passwordHash: await hashPassword(deletionCredential()) };
      if (process.env.DATABASE_URL) {
        await repo.deleteUserPrivacyBundle(me.id, replacement);
      } else {
        const deletedAt = now();
        db.collection.evidence.forEach(x => { if (x.submittedBy === me.id) x.submittedBy = null; });
        db.collection.uploads.forEach(x => { if (x.uploadedBy === me.id) x.uploadedBy = null; });
        db.collection.refreshTokens = db.collection.refreshTokens.filter(x=>x.userId!==me.id);
        db.collection.resetTokens = db.collection.resetTokens.filter(x=>x.userId!==me.id);
        db.collection.notificationDevices = db.collection.notificationDevices.filter(x=>x.userId!==me.id);
        db.collection.notificationPreferences = db.collection.notificationPreferences.filter(x=>x.userId!==me.id);
        db.collection.notifications = db.collection.notifications.filter(x=>x.userId!==me.id);
        db.collection.analyticsEvents = db.collection.analyticsEvents.filter(x=>x.userId!==me.id);
        db.collection.crashReports = db.collection.crashReports.filter(x=>x.userId!==me.id);
        const u=await findUser(me.id); if (u) Object.assign(u,{email:replacement.email,passwordHash:replacement.passwordHash,displayName:'Deleted user',status:'DELETED',sessionVersion:Number(u.sessionVersion||0)+1,deletedAt});
        for (const j of db.collection.jobs) if (j.providerId===me.id && ['DRAFT','PUBLISHED'].includes(j.status)) j.providerId=null;
        db.touch('refreshTokens','resetTokens','notificationDevices','notificationPreferences','notifications','analyticsEvents','crashReports','users','jobs');
        await db.save();
      }
      return sendJson(res,200,{deleted:true,privacyVersion:'1.1'});
    }
    throw new HttpError(404,'NOT_FOUND','Account privacy route not found');
  };
}
