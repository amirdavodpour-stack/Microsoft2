// Candidate application routes.

export function createApplicationRoutes({ authUser, readBody, sendJson, HttpError, requireFields, textField, repo, db, getJob, createAudit, now, notifyUser, NOTIFICATION_TYPES }) {
  return async function routeHandler(req, res, parts) {
    if (req.method === 'POST' && parts[0] === 'applications' && parts.length === 3 && parts[2] === 'withdraw') {
      const me = await authUser(req);
      const id = parts[1];
      let changed = null;
      if (process.env.DATABASE_URL) {
        changed = await repo.transitionCandidateApplication(id, me.id, ['PENDING','SHORTLISTED','FORWARDED','INTERVIEW'], 'WITHDRAWN');
      } else {
        const a = db.collection.jobApplications.find(x => x.id === id && x.candidateId === me.id && ['PENDING','SHORTLISTED','FORWARDED','INTERVIEW'].includes(x.status));
        if (a) { a.status='WITHDRAWN'; a.updatedAt=now(); db.touch('jobApplications'); changed=a; await db.save(); }
      }
      if (!changed) throw new HttpError(409,'INVALID_APPLICATION_STATE','Application cannot be withdrawn from its current state');
      await createAudit('JOB_APPLICATION_WITHDRAW', me.id, 'job_application', id);
      return sendJson(res,200,{id:changed.id,status:changed.status});
    }
    if (req.method === 'GET' && parts.length === 1) {
      const me = await authUser(req);
      const applications = process.env.DATABASE_URL ? await repo.listCandidateApplications(me.id) : db.collection.jobApplications.filter(a=>a.candidateId===me.id).map(a=>{const j=db.collection.jobs.find(x=>x.id===a.jobId); return {...a,jobTitle:j?.title||'—',jobCity:j?.city||null,jobKind:j?.kind||'JOB'};});
      return sendJson(res,200,applications.map(({candidateId,...safe})=>safe));
    }
    if (req.method === 'POST' && parts.length === 3 && parts[0] === 'admin') {
      throw new HttpError(404,'NOT_FOUND','Use admin application routes');
    }
    if (req.method === 'POST' && parts.length === 1) {
      const me = await authUser(req); const body = await readBody(req); requireFields(body, ['jobId','resumeText']);
      const job = await getJob(String(body.jobId)); if (!job) throw new HttpError(404,'JOB_NOT_FOUND','Job not found');
      if ((job.kind || (job.jobType === 'FIXED' ? 'MISSION' : 'JOB')) !== 'JOB') throw new HttpError(400,'JOB_ONLY','Applications are only available for jobs');
      if (job.status !== 'PUBLISHED') throw new HttpError(409,'APPLICATION_CLOSED','This job is not accepting applications');
      if (job.ownerId === me.id) throw new HttpError(403,'FORBIDDEN','Owners cannot apply to their own job');
      if (job.applicationDeadline) {
        const deadline = new Date(`${String(job.applicationDeadline).slice(0, 10)}T23:59:59.999Z`);
        if (Number.isNaN(deadline.getTime()) || deadline.getTime() < Date.now()) throw new HttpError(409,'APPLICATION_CLOSED','Application deadline has passed');
      }
      const existing = process.env.DATABASE_URL ? await repo.findJobApplication(job.id,me.id) : db.collection.jobApplications.find(a=>a.jobId===job.id&&a.candidateId===me.id&&['PENDING','SHORTLISTED','FORWARDED','INTERVIEW','OFFERED','ACCEPTED'].includes(a.status));
      if(existing) throw new HttpError(409,'APPLICATION_EXISTS','You already applied to this job');
      const resumeText=textField(body.resumeText,'resumeText',{min:10,max:12000,required:true}); const skills=textField(body.skills || '','skills',{min:0,max:2000});
      const draft={id:db.id(),jobId:job.id,candidateId:me.id,resumeText,skills,status:'PENDING',createdAt:now(),updatedAt:now()};
      let created;
      try {
        created=process.env.DATABASE_URL?await repo.insertJobApplication(draft):db.insert('jobApplications',draft);
      } catch (error) {
        if (error?.code === '23505') throw new HttpError(409,'APPLICATION_EXISTS','You already applied to this job');
        throw error;
      }
      await notifyUser({userId:job.ownerId,type:NOTIFICATION_TYPES.JOB_APPLICATION_RECEIVED,title:'درخواست جدید برای شغل شما',body:`برای «${job.title}» یک درخواست جدید دریافت کردید.`,data:{jobId:job.id,applicationId:created.id},dedupeKey:`application:${created.id}:owner`,channels:['IN_APP','PUSH','EMAIL']});
      await createAudit('JOB_APPLICATION_CREATE',me.id,'job_application',created.id,{jobId:job.id}); return sendJson(res,201,{id:created.id,status:created.status});
    }
    throw new HttpError(404,'NOT_FOUND','Application route not found');
  };
}
