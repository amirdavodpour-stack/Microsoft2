import { config } from './config.js';
import { claimOutboxEvent } from './repository.js';
import { logEvent } from './observability.js';
import { processOutboxEvent } from './outbox_handlers.js';

let stopped = false;
let timer = null;
let busy = false;

async function processOne() {
  if (busy || stopped) return false;
  busy = true;
  try {
    const event = await claimOutboxEvent(config.outboxLeaseSeconds);
    if (!event) return false;
    await processOutboxEvent(event);
    return true;
  } finally {
    busy = false;
  }
}

export function startOutboxWorker() {
  if (!process.env.DATABASE_URL) return { stop() {} };
  stopped = false;
  const tick = async () => {
    if (stopped) return;
    try { await processOne(); } catch (error) { console.error('[outbox] worker error:', error.message); }
    timer = setTimeout(tick, config.outboxPollMs);
    timer.unref?.();
  };
  timer = setTimeout(tick, 0);
  timer.unref?.();
  return { stop() { stopped = true; if (timer) clearTimeout(timer); } };
}

export async function processPaymentReleaseNow() { return processOne(); }
export async function processPaymentCreateHoldNow() { return processOne(); }
export async function processPaymentRefundNow() { return processOne(); }
