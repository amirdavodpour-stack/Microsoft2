import crypto from 'node:crypto';
import { withSqlTransaction } from '../db.js';
import { requirePool } from './context.js';

const notificationFromRow = (r) => ({
  id: r.id,
  userId: r.user_id,
  type: r.type,
  title: r.title,
  body: r.body,
  data: r.data || {},
  dedupeKey: r.dedupe_key || null,
  readAt: r.read_at ? (r.read_at.toISOString?.() ?? r.read_at) : null,
  createdAt: r.created_at?.toISOString?.() ?? r.created_at,
});

export async function ensureNotificationPreferences(userId) {
  const { rows } = await requirePool().query(`
    INSERT INTO notification_preferences(id,user_id) VALUES(gen_random_uuid(),$1)
    ON CONFLICT(user_id) DO UPDATE SET user_id=EXCLUDED.user_id
    RETURNING id,user_id,in_app,push,email,job_alerts,application_updates,payment_updates,marketing,updated_at
  `, [userId]);
  const r = rows[0];
  return {
    id:r.id,userId:r.user_id,inApp:r.in_app,push:r.push,email:r.email,jobAlerts:r.job_alerts,
    applicationUpdates:r.application_updates,paymentUpdates:r.payment_updates,marketing:r.marketing,
    updatedAt:r.updated_at?.toISOString?.() ?? r.updated_at,
  };
}

export async function getNotificationPreferences(userId) { return ensureNotificationPreferences(userId); }

export async function updateNotificationPreferences(userId, patch) {
  const current = await ensureNotificationPreferences(userId);
  const next = {...current, ...patch};
  const { rows } = await requirePool().query(
    `UPDATE notification_preferences SET in_app=$2,push=$3,email=$4,job_alerts=$5,application_updates=$6,payment_updates=$7,marketing=$8,updated_at=NOW() WHERE user_id=$1 RETURNING id,user_id,in_app,push,email,job_alerts,application_updates,payment_updates,marketing,updated_at`,
    [userId,!!next.inApp,!!next.push,!!next.email,!!next.jobAlerts,!!next.applicationUpdates,!!next.paymentUpdates,!!next.marketing],
  );
  return ensureNotificationPreferencesFromRow(rows[0]);
}

function ensureNotificationPreferencesFromRow(r) {
  return {
    id:r.id,userId:r.user_id,inApp:r.in_app,push:r.push,email:r.email,jobAlerts:r.job_alerts,
    applicationUpdates:r.application_updates,paymentUpdates:r.payment_updates,marketing:r.marketing,
    updatedAt:r.updated_at?.toISOString?.() ?? r.updated_at,
  };
}

export async function listNotifications(userId, limit=50, offset=0) {
  const {rows} = await requirePool().query(
    `SELECT * FROM notifications WHERE user_id=$1 ORDER BY created_at DESC LIMIT $2 OFFSET $3`,
    [userId,Math.min(Math.max(Number(limit)||50,1),100),Math.max(Number(offset)||0,0)],
  );
  return rows.map(notificationFromRow);
}

export async function markNotificationRead(id,userId) {
  const {rows} = await requirePool().query(
    `UPDATE notifications SET read_at=COALESCE(read_at,NOW()) WHERE id=$1 AND user_id=$2 RETURNING *`,
    [id,userId],
  );
  return rows[0] ? notificationFromRow(rows[0]) : null;
}

export async function markAllNotificationsRead(userId) {
  const {rowCount}=await requirePool().query(
    `UPDATE notifications SET read_at=COALESCE(read_at,NOW()) WHERE user_id=$1 AND read_at IS NULL`, [userId],
  );
  return {updated:rowCount};
}

export async function countUnreadNotifications(userId) {
  const {rows}=await requirePool().query(
    `SELECT COUNT(*)::int AS count FROM notifications WHERE user_id=$1 AND read_at IS NULL`, [userId],
  );
  return Number(rows[0]?.count||0);
}

export async function registerNotificationDevice({id,userId,platform,token,enabled=true}) {
  const {rows}=await requirePool().query(
    `INSERT INTO notification_devices(id,user_id,platform,token,enabled) VALUES($1,$2,$3,$4,$5) ON CONFLICT(token) DO UPDATE SET user_id=EXCLUDED.user_id,platform=EXCLUDED.platform,enabled=EXCLUDED.enabled,updated_at=NOW() RETURNING *`,
    [id,userId,platform,token,enabled],
  );
  const r=rows[0];
  return {id:r.id,userId:r.user_id,platform:r.platform,token:r.token,enabled:r.enabled,createdAt:r.created_at?.toISOString?.() ?? r.created_at,updatedAt:r.updated_at?.toISOString?.() ?? r.updated_at};
}

export async function listNotificationDevices(userId, { includeToken = true } = {}) {
  const {rows}=await requirePool().query(
    `SELECT id,user_id,platform,token,enabled,created_at,updated_at FROM notification_devices WHERE user_id=$1 AND enabled=true ORDER BY updated_at DESC`, [userId],
  );
  return rows.map(r=>({id:r.id,userId:r.user_id,platform:r.platform,...(includeToken ? { token:r.token } : {}),enabled:r.enabled,createdAt:r.created_at?.toISOString?.() ?? r.created_at,updatedAt:r.updated_at?.toISOString?.() ?? r.updated_at}));
}

export async function getUserEmail(userId) {
  const {rows}=await requirePool().query(`SELECT email FROM users WHERE id=$1 LIMIT 1`,[userId]);
  return rows[0]?.email || null;
}

export async function disableNotificationDevice(id,userId) {
  const {rows}=await requirePool().query(`UPDATE notification_devices SET enabled=false,updated_at=NOW() WHERE id=$1 AND user_id=$2 RETURNING *`,[id,userId]);
  const r=rows[0];
  return r?{id:r.id,userId:r.user_id,platform:r.platform,enabled:r.enabled,createdAt:r.created_at?.toISOString?.() ?? r.created_at,updatedAt:r.updated_at?.toISOString?.() ?? r.updated_at}:null;
}

export async function queueNotification({userId,type,title,body,data={},dedupeKey=null,channels=['IN_APP']}) {
  const id=crypto.randomUUID();
  return withSqlTransaction(async(client)=>{
    const payload={...data,dedupeKey:dedupeKey||undefined,channels};
    const {rows}=await client.query(`INSERT INTO notifications(id,user_id,type,title,body,data,dedupe_key,created_at) VALUES($1,$2,$3,$4,$5,$6::jsonb,$7,NOW()) ON CONFLICT(user_id,dedupe_key) WHERE dedupe_key IS NOT NULL AND dedupe_key <> '' DO UPDATE SET id=notifications.id RETURNING *`,[id,userId,type,title,body,JSON.stringify(payload),dedupeKey || null]);
    if (!rows[0]) return { notification: null, created: false };
    const notification = rows[0];
    const created = notification.id === id;
    if (!created) return { notification: notificationFromRow(notification), created: false };
    const notifyChannels=Array.from(new Set(channels));
    for(const ch of notifyChannels.filter(Boolean)){
      await client.query(`INSERT INTO notification_deliveries(id,notification_id,channel,status,attempts,created_at,updated_at) VALUES(gen_random_uuid(),$1,$2,$3,0,NOW(),NOW()) ON CONFLICT(notification_id,channel) DO NOTHING`, [notification.id, ch, ch === 'IN_APP' ? 'DELIVERED' : 'PENDING']);
      const eventId=crypto.randomUUID();
      await client.query(`INSERT INTO outbox_events(id,event_type,aggregate_type,aggregate_id,dedupe_key,payload,status,attempts,available_at,created_at) VALUES($1,'NOTIFICATION_DISPATCH','notification',$2,$3,$4::jsonb,'PENDING',0,NOW(),NOW()) ON CONFLICT(dedupe_key) DO NOTHING`,[eventId,notification.id,`NOTIFICATION:${notification.id}:${ch}`,JSON.stringify({notificationId:notification.id,userId,type,channel:ch,title,body,data})]);
    }
    return {notification:notificationFromRow(notification),created};
  });
}

export async function markNotificationDeliveryDelivered(notificationId, channel, providerMessageId = null) {
  const { rows } = await requirePool().query(`UPDATE notification_deliveries SET status='DELIVERED',attempts=attempts+1,provider_message_id=$3,delivered_at=COALESCE(delivered_at,NOW()),updated_at=NOW(),last_error=NULL WHERE notification_id=$1 AND channel=$2 RETURNING *`, [notificationId, channel, providerMessageId]);
  return rows[0] || null;
}

export async function markNotificationDeliveryFailed(notificationId, channel, error, terminal = false) {
  const status = terminal ? 'FAILED' : 'PENDING';
  const { rows } = await requirePool().query(`UPDATE notification_deliveries SET status=$3,attempts=attempts+1,last_error=$4,updated_at=NOW() WHERE notification_id=$1 AND channel=$2 RETURNING *`, [notificationId, channel, status, String(error || '').slice(0,2000)]);
  return rows[0] || null;
}
