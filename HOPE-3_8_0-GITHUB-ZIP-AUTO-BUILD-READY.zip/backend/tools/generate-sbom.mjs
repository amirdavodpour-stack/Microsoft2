#!/usr/bin/env node
// Generates a CycloneDX 1.5 SBOM from the application package.json and the
// exact npm package-lock.json tree. This intentionally avoids third-party
// tooling so it is reproducible before/after npm ci.
import fs from 'node:fs';
import crypto from 'node:crypto';

const pkg = JSON.parse(fs.readFileSync(new URL('../package.json', import.meta.url), 'utf8'));
const lock = JSON.parse(fs.readFileSync(new URL('../package-lock.json', import.meta.url), 'utf8'));

const components = [];
for (const [location, node] of Object.entries(lock.packages || {})) {
  if (!location || !node || !node.version) continue;
  const name = location.replace(/^node_modules\//, '').split('node_modules/').at(-1);
  if (!name || name === 'hope-api') continue;
  const scope = location.includes('/node_modules/') ? 'optional' : 'required';
  components.push({
    type: 'library',
    name,
    version: node.version,
    purl: `pkg:npm/${encodeURIComponent(name)}@${node.version}`,
    scope,
  });
}

components.sort((a,b) => `${a.name}@${a.version}`.localeCompare(`${b.name}@${b.version}`));

const sourceDateEpoch = process.env.SOURCE_DATE_EPOCH ? Number(process.env.SOURCE_DATE_EPOCH) : Math.floor(Date.now() / 1000);
if (!Number.isSafeInteger(sourceDateEpoch) || sourceDateEpoch < 0) throw new Error('SOURCE_DATE_EPOCH must be a non-negative integer when set');
const timestamp = new Date(sourceDateEpoch * 1000).toISOString();
const canonical = JSON.stringify({ name: pkg.name, version: pkg.version, components });
const serial = crypto.createHash('sha256').update(canonical).digest('hex').slice(0, 32);
const sbom = {
  bomFormat: 'CycloneDX',
  specVersion: '1.5',
  serialNumber: `urn:uuid:${serial.slice(0,8)}-${serial.slice(8,12)}-5${serial.slice(13,16)}-${serial.slice(16,20)}-${serial.slice(20,32)}`,
  version: 1,
  metadata: {
    timestamp,
    component: { type: 'application', name: pkg.name, version: pkg.version },
  },
  components,
};

fs.writeFileSync(new URL('../sbom.json', import.meta.url), JSON.stringify(sbom, null, 2) + '\n');
console.log(`sbom.json written: ${components.length} locked npm components`);
