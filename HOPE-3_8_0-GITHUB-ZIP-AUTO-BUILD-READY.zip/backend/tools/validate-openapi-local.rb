#!/usr/bin/env ruby
# Deterministic, dependency-free OpenAPI 3.x structural validator.
# It intentionally avoids runtime npm installs so CI validation is reproducible.
require 'yaml'
require 'json'

path = ARGV[0] || File.join(__dir__, '..', 'openapi', 'openapi.yaml')
raise "OpenAPI file not found: #{path}" unless File.file?(path)

doc = YAML.safe_load(File.read(path, encoding: 'UTF-8'), permitted_classes: [], aliases: false)
errors = []
warnings = []

errors << 'root must be an object' unless doc.is_a?(Hash)
if doc.is_a?(Hash)
  errors << 'openapi must be 3.0.x' unless doc['openapi'].to_s.match?(/\A3\.0(?:\.\d+)?\z/)
  info = doc['info']
  errors << 'info.title is required' unless info.is_a?(Hash) && info['title'].to_s != ''
  errors << 'info.version is required' unless info.is_a?(Hash) && info['version'].to_s != ''

  paths = doc['paths']
  errors << 'paths must be an object' unless paths.is_a?(Hash)
  seen_operation_ids = {}
  allowed_methods = %w[get put post delete options head patch trace]

  if paths.is_a?(Hash)
    paths.each do |path_name, path_item|
      errors << "invalid path #{path_name.inspect}" unless path_name.to_s.start_with?('/')
      unless path_item.is_a?(Hash)
        errors << "path item #{path_name} must be an object"
        next
      end
      allowed_methods.each do |method|
        operation = path_item[method]
        next if operation.nil?
        unless operation.is_a?(Hash)
          errors << "#{method.upcase} #{path_name} must be an object"
          next
        end
        opid = operation['operationId']
        if opid && opid.to_s != ''
          if seen_operation_ids.key?(opid)
            errors << "duplicate operationId: #{opid} (#{seen_operation_ids[opid]} and #{method.upcase} #{path_name})"
          else
            seen_operation_ids[opid] = "#{method.upcase} #{path_name}"
          end
        end
        responses = operation['responses']
        errors << "#{method.upcase} #{path_name} is missing responses" unless responses.is_a?(Hash) && !responses.empty?
      end
    end
  end

  security_schemes = doc.dig('components', 'securitySchemes')
  if security_schemes.is_a?(Hash)
    bearer = security_schemes['bearerAuth']
    errors << 'bearerAuth security scheme is missing or invalid' unless bearer.is_a?(Hash) && bearer['type'] == 'http' && bearer['scheme'].to_s.downcase == 'bearer'
  else
    warnings << 'components.securitySchemes is absent'
  end

  refs = []
  walker = lambda do |node, location|
    case node
    when Hash
      node.each { |k, v| refs << [v.to_s, location] if k == '$ref'; walker.call(v, "#{location}.#{k}") unless k == '$ref' }
    when Array
      node.each_with_index { |v, i| walker.call(v, "#{location}[#{i}]") }
    end
  end
  walker.call(doc, '$')
  refs.each do |ref, location|
    if ref.start_with?('#/')
      target = doc
      ref.split('/')[1..].each do |segment|
        segment = segment.gsub('~1', '/').gsub('~0', '~')
        target = target.is_a?(Hash) ? target[segment] : nil
      end
      errors << "unresolved local $ref #{ref} at #{location}" if target.nil?
    else
      warnings << "external $ref not resolved locally: #{ref} at #{location}"
    end
  end
end

puts JSON.pretty_generate({status: errors.empty? ? 'PASS' : 'FAIL', errors: errors, warnings: warnings})
exit(errors.empty? ? 0 : 1)
