import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { execFileSync } from 'node:child_process';

const root = path.resolve(new URL('..', import.meta.url).pathname);
const evidenceDir = path.join(root, 'artifacts', 'release-evidence');
fs.mkdirSync(evidenceDir, { recursive: true });

const sourceDateEpoch = process.env.SOURCE_DATE_EPOCH ? Number(process.env.SOURCE_DATE_EPOCH) : (() => {
  try {
    return Number(execFileSync('git', ['-C', root, 'show', '-s', '--format=%ct', 'HEAD'], { encoding: 'utf8' }).trim());
  } catch { return Math.floor(Date.now() / 1000); }
})();
if (!Number.isSafeInteger(sourceDateEpoch) || sourceDateEpoch < 0) throw new Error('SOURCE_DATE_EPOCH must be a non-negative integer when set');
const now = new Date(sourceDateEpoch * 1000);
const evidence = {
  schemaVersion: 1,
  generatedAt: now.toISOString(),
  platform: `${process.platform}/${process.arch}`,
  hostname: os.hostname(),
  node: process.version,
  commit: process.env.GITHUB_SHA || process.env.GIT_COMMIT || 'UNKNOWN',
  ref: process.env.GITHUB_REF || 'UNKNOWN',
  runId: process.env.GITHUB_RUN_ID || 'LOCAL',
  status: process.env.RELEASE_STATUS || 'UNKNOWN',
  passed: Number(process.env.RELEASE_GATES_PASSED || 0),
  blocked: Number(process.env.RELEASE_GATES_BLOCKED || 0),
};
const out = path.join(evidenceDir, 'release-evidence.json');
fs.writeFileSync(out, `${JSON.stringify(evidence, null, 2)}\n`);
console.log(out);
