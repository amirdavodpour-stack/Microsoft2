#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

fail=0
# Private key material must never be tracked in a source distribution.
if grep -RInE --exclude-dir=.git --exclude='*.md' --exclude='package-lock.json' --exclude='sbom.json' -- '-----BEGIN (RSA |EC |OPENSSH )?PRIVATE KEY-----' .; then
  echo 'ERROR: private key material detected in source tree.' >&2
  fail=1
fi
# Reject obvious live secret assignment patterns while allowing documented env names.
if grep -RInE --exclude-dir=.git --exclude='*.md' --exclude='package-lock.json' --exclude='sbom.json' --exclude='.env.example' --exclude='.env.koyeb.neon.r2.example' --include='*.js' --include='*.mjs' --include='*.dart' --include='*.kt' --include='*.kts' -- '(^|[[:space:]])(AWS_SECRET_ACCESS_KEY|PAYMENT_WEBHOOK_SECRET|PAYMENT_PROVIDER_TOKEN|ACCESS_TOKEN_SECRET|REFRESH_TOKEN_SECRET)=[A-Za-z0-9_./+=-]{20,}' .; then
  echo 'ERROR: possible hard-coded secret assignment detected.' >&2
  fail=1
fi
# Ensure secrets/config files are ignored.
grep -q '^\.env$' .gitignore || { echo 'ERROR: .env is not ignored.' >&2; fail=1; }
grep -q '^\*\.jks$' .gitignore || { echo 'ERROR: *.jks is not ignored.' >&2; fail=1; }
grep -q '^\*\.keystore$' .gitignore || { echo 'ERROR: *.keystore is not ignored.' >&2; fail=1; }
exit "$fail"
