#!/usr/bin/env bash
set -euo pipefail
python3 - <<'PY'
import json,re
from pathlib import Path
root=Path('.')
en=json.loads((root/'lib/l10n/app_en.arb').read_text()); fa=json.loads((root/'lib/l10n/app_fa.arb').read_text())
keys=lambda d:{k for k in d if not k.startswith('@') and k!='@@locale'}
ek,fk=keys(en),keys(fa)
assert ek==fk, f'ARB key mismatch: en-only={ek-fk}, fa-only={fk-ek}'
helper=(root/'lib/core/ui/hope_l10n.dart').read_text()
names=set(re.findall(r'String get (\w+) => value\.\1;', helper))
names.update(re.findall(r'String (\w+)\([^)]*\) => value\.\1\([^)]*\);', helper))
assert ek <= names, f'Missing localization helpers: {sorted(ek-names)[:10]}'
for f in (root/'lib').rglob('*.dart'):
    if f == root/'lib/core/ui/copy.dart': continue
    t=f.read_text()
    assert 'tx(context' not in t, f'Manual tx() remains in {f}'
print(f'PASS: {len(ek)} ARB keys, parity OK, helper complete, manual tx() eliminated.')
PY
