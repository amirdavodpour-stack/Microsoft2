import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const failures = [];
const warnings = [];
const read = (p) => fs.readFileSync(path.join(root, p), 'utf8');
const walk = (dir, out=[]) => {
  for (const ent of fs.readdirSync(path.join(root,dir), {withFileTypes:true})) {
    const rel = path.join(dir, ent.name);
    if (['node_modules','.dart_tool','build','.git'].includes(ent.name)) continue;
    if (ent.isDirectory()) walk(rel,out); else out.push(rel);
  }
  return out;
};
const files = walk('.');
const workflows = files.filter(f => f.startsWith('.github/workflows/') && f.endsWith('.yml'));
for (const wf of workflows) {
  const text = read(wf);
  for (const line of text.split('\n')) {
    const m = line.match(/uses:\s+([^@\s]+)@([^\s#]+)/);
    if (!m) continue;
    if (!/^[0-9a-f]{40}$/i.test(m[2])) failures.push(`${wf}: unpinned action ${m[1]}@${m[2]}`);
  }
  if (/continue-on-error:\s*true/.test(text) && !/cache\/(restore|save)@/.test(text)) warnings.push(`${wf}: review continue-on-error`);
}
const pubspec = read('pubspec.yaml');
if (!pubspec.includes('generate: true')) failures.push('pubspec.yaml: flutter.generate must be true');
if (fs.existsSync(path.join(root,'pubspec.lock'))) warnings.push('pubspec.lock present; CI should enforce --enforce-lockfile');
else if (process.env.CI_ENFORCE_LOCKFILE === '1') failures.push('pubspec.lock: required for application reproducibility');
else warnings.push('pubspec.lock: absent locally; CI_ENFORCE_LOCKFILE=1 will fail until a real Flutter lockfile is committed');
const gradleProps = read('android/gradle/wrapper/gradle-wrapper.properties');
if (!/gradle-8\.13-[^\s]+\.zip/.test(gradleProps)) failures.push('Gradle wrapper: expected 8.13 distribution');
const kt = read('android/app/build.gradle.kts');
if (!kt.includes('JvmTarget.fromTarget("17")')) failures.push('Kotlin JVM target 17 is not enforced by typed compiler options');
const server = read('backend/src/server.js');
const security = read('backend/src/security.js');
const config = read('backend/src/config.js');
if (!security.includes("header.alg !== 'HS256'")) failures.push('JWT algorithm allowlist missing');
if (!config.includes('ACCESS_TOKEN_SECRET_PREVIOUS')) failures.push('JWT key rotation configuration missing');
for (const wf of workflows) {
  const text = read(wf);
  if (/npm install[^\n]*swagger-parser/i.test(text)) failures.push(`${wf}: dynamic swagger-parser installation is forbidden for reproducible CI`);
}
if (!fs.existsSync(path.join(root, 'backend/tools/validate-openapi-local.rb'))) failures.push('OpenAPI: deterministic local validator missing');
const schema = read('backend/src/db/schema.js');
if (!schema.includes('notifications_user_dedupe_uq')) failures.push('notification dedupe constraint missing');
if (!schema.includes('Duplicate normalized user emails prevent safe migration')) failures.push('email normalization preflight missing');
if (/headersTimeout\s*=\s*Math\.max/.test(server)) failures.push('HTTP header timeout may exceed configured request timeout');
if (failures.length) {
  console.error(JSON.stringify({status:'FAIL', failures, warnings}, null, 2));
  process.exit(1);
}
console.log(JSON.stringify({status:'PASS', failures:[], warnings}, null, 2));
