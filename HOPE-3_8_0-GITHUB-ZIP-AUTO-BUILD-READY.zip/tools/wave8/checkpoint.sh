#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
SHA="${GITHUB_SHA:-$(git -C "$ROOT" rev-parse HEAD 2>/dev/null || echo UNKNOWN)}"
GATE="${1:?gate id required}"
ARTIFACT_ROOT="${ARTIFACT_ROOT:-$ROOT/artifacts/wave8}"
RESULT="$ARTIFACT_ROOT/gates/$GATE.json"
[[ -s "$RESULT" ]] || exit 1
python3 - "$RESULT" "$SHA" <<'PY'
import json,sys
p=sys.argv[1]; expected=sys.argv[2]
obj=json.load(open(p))
assert obj.get('commitSha')==expected, 'stale checkpoint commit'
assert obj.get('gate')
assert obj.get('status') in {'PASS','FAIL','BLOCKED_TOOLCHAIN','BLOCKED_INFRA','SKIPPED_DEPENDENCY','TIMEOUT','ERROR'}
assert obj.get('artifacts') is not None
print('VALID_CHECKPOINT', obj['gate'], obj['status'])
PY
