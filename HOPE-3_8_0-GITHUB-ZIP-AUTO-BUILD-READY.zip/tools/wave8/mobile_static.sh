#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"; cd "$ROOT"
if ! command -v flutter >/dev/null 2>&1; then echo 'Flutter SDK unavailable' >&2; exit 200; fi
bash tools/verify-pubspec-lock-fresh.sh
flutter pub get --enforce-lockfile
flutter gen-l10n
bash tools/verify-pubspec-lock-fresh.sh
flutter analyze
if command -v dart >/dev/null 2>&1; then dart format --output=none --set-exit-if-changed lib test integration_test; fi
bash tools/check_localization.sh
bash tools/android-release-contract.sh
bash tools/wave8/flutter_gradle_structural_audit.sh
