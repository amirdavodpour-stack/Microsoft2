#!/usr/bin/env bash
set -euo pipefail
kind="${1:?kind}"
case "$kind" in
  postgres) command -v psql >/dev/null 2>&1 || { echo 'PostgreSQL client unavailable' >&2; exit 200; }; [[ -n "${DATABASE_URL:-}" ]] || { echo 'DATABASE_URL missing' >&2; exit 201; };;
  storage)
    [[ -n "${STAGING_S3_ENDPOINT:-${S3_ENDPOINT:-}}" && -n "${S3_BUCKET:-}" && -n "${AWS_ACCESS_KEY_ID:-}" && -n "${AWS_SECRET_ACCESS_KEY:-}" ]] || { echo "storage staging infrastructure/credentials unavailable" >&2; exit 201; } ;;
  payment)
    [[ -n "${PAYMENT_PROVIDER_URL:-${PAYMENT_PROVIDER_CREATE_URL:-}}" && -n "${PAYMENT_PROVIDER_TOKEN:-}" && -n "${PAYMENT_PROVIDER_CREATE_URL:-}" && -n "${PAYMENT_PROVIDER_RELEASE_URL:-}" && -n "${PAYMENT_PROVIDER_REFUND_URL:-}" ]] || { echo "payment staging infrastructure/credentials unavailable" >&2; exit 201; } ;;
  notification)
    [[ -n "${NOTIFICATION_PROVIDER_URL:-${NOTIFICATION_PUSH_URL:-}${NOTIFICATION_EMAIL_URL:-}}" && -n "${NOTIFICATION_PROVIDER_TOKEN:-}" ]] || { echo "notification staging infrastructure/credentials unavailable" >&2; exit 201; } ;;
  performance)
    [[ -n "${STAGING_API_BASE_URL:-}" ]] || { echo "performance staging infrastructure unavailable" >&2; exit 201; } ;;

  emulator) command -v adb >/dev/null 2>&1 || { echo 'Android emulator/adb unavailable' >&2; exit 200; }; apk="${APK_PATH:-build/app/outputs/flutter-apk/app-release.apk}"; test -s "$apk" || { echo "APK missing: $apk" >&2; exit 202; };;
  *) exit 1;;
esac
