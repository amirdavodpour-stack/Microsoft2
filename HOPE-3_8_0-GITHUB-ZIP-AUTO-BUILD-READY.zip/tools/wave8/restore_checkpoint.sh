#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
GATE="${1:?gate id required}"
ARTIFACT_ROOT="${ARTIFACT_ROOT:-$ROOT/artifacts/wave8}"
RESULT="$ARTIFACT_ROOT/gates/$GATE.json"
[[ -s "$RESULT" ]] || exit 1
EXPECTED="${GITHUB_SHA:-$(git -C "$ROOT" rev-parse HEAD 2>/dev/null || echo UNKNOWN)}"
python3 - "$RESULT" "$EXPECTED" "$GATE" "$ROOT" <<'PY'
import json,os,sys
p,expected,gate,root=sys.argv[1:]
o=json.load(open(p,encoding='utf-8'))
required={'schemaVersion','gate','status','exitCode','startedAt','finishedAt','durationSeconds','toolchain','metrics','artifacts','errors','warnings','commitSha'}
assert not (required-set(o)), f'missing fields: {sorted(required-set(o))}'
assert o['gate']==gate and o['commitSha']==expected and o['status']=='PASS', 'checkpoint identity/status invalid'
assert isinstance(o['artifacts'],list), 'artifacts must be list'
for a in o['artifacts']:
    assert isinstance(a,str) and not os.path.isabs(a) and not a.startswith('../') and '\\' not in a, f'unsafe artifact path: {a!r}'
    assert os.path.exists(os.path.join(root,a)), f'missing artifact: {a}'
print('VALID_REUSABLE_CHECKPOINT',gate)
PY
