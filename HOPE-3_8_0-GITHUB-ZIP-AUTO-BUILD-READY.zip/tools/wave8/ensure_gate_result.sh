#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
GATE="${1:?gate id required}"
STATUS="${2:?status required}"
MESSAGE="${3:?message required}"
ARTIFACT_ROOT="${ARTIFACT_ROOT:-$ROOT/artifacts/wave8}"
RESULT="$ARTIFACT_ROOT/gates/$GATE.json"
mkdir -p "$ARTIFACT_ROOT/gates" "$ARTIFACT_ROOT/logs/$GATE" "$ARTIFACT_ROOT/metrics/$GATE"
[[ -s "$RESULT" ]] && exit 0
SHA="${GITHUB_SHA:-$(git -C "$ROOT" rev-parse HEAD 2>/dev/null || echo UNKNOWN)}"
RUN_ID="${GITHUB_RUN_ID:-LOCAL}"
NOW="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
python3 - "$RESULT" "$GATE" "$STATUS" "$MESSAGE" "$SHA" "$RUN_ID" "$NOW" <<'PY'
import json,sys
p,gate,status,msg,sha,run_id,now=sys.argv[1:]
allowed={'PASS','FAIL','BLOCKED_TOOLCHAIN','BLOCKED_INFRA','SKIPPED_DEPENDENCY','TIMEOUT','ERROR'}
if status not in allowed: raise SystemExit(f'Invalid status: {status}')
o={'schemaVersion':1,'gate':gate,'status':status,'exitCode':200 if status=='BLOCKED_TOOLCHAIN' else 201 if status=='BLOCKED_INFRA' else 1,'startedAt':now,'finishedAt':now,'durationSeconds':0,'commitSha':sha,'workflowRunId':run_id,'toolchain':{},'metrics':{},'artifacts':[],'errors':[{'type':status,'message':msg}],'warnings':[]}
json.dump(o,open(p,'w'),indent=2); open(p,'a').write('\n')
PY
