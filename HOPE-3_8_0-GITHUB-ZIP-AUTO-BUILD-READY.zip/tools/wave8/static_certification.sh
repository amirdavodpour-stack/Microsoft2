#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"; cd "$ROOT"
bash tools/check_node_syntax.sh
bash -n tools/*.sh tools/wave8/*.sh
ruby -e 'require "yaml"; ARGV.each { |p| YAML.load_file(p, aliases: true) }' $(find . -type f \( -name "*.yml" -o -name "*.yaml" \) -not -path "./.git/*" -not -path "./build/*" -not -path "./artifacts/*" -not -path "./wave8-certification/*")
python3 tools/verify_toolchain_alignment.py
python3 - <<'PY'
import json,glob
for p in glob.glob('**/*.json',recursive=True):
 if '/node_modules/' not in p and '/.git/' not in p:
  json.load(open(p,encoding='utf-8'))
PY
command -v node >/dev/null
if [[ -f backend/openapi/openapi.yaml ]]; then
  tools/wave8/require_node24.sh
  (cd backend && npm ci --ignore-scripts && node tools/validate-openapi.mjs)
fi
if command -v flutter >/dev/null 2>&1; then flutter analyze; else echo 'Flutter unavailable; mobile static portion will be certified as BLOCKED by dedicated gate.'; fi
