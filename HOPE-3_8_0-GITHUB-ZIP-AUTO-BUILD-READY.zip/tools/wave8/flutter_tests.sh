#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"; cd "$ROOT"
if ! command -v flutter >/dev/null 2>&1; then echo 'Flutter SDK unavailable' >&2; exit 200; fi
if [[ ! -f pubspec.lock ]]; then echo 'pubspec.lock is required for reproducible Flutter tests' >&2; exit 200; fi
mkdir -p artifacts/wave8/reports/flutter-tests artifacts/wave8/metrics/flutter
# Bound the heavyweight suite independently from the enclosing GitHub job timeout.
timeout --signal=TERM --kill-after=30s 25m flutter test --concurrency=1 --coverage test > artifacts/wave8/reports/flutter-tests/flutter-test.log 2>&1
cp coverage/lcov.info artifacts/wave8/metrics/flutter/lcov.info
