#!/usr/bin/env python3
import json
import os
import sys

ALLOWED = {'PASS','FAIL','TIMEOUT','BLOCKED_TOOLCHAIN','BLOCKED_INFRA','SKIPPED_DEPENDENCY','ERROR'}
REQUIRED = {
    'schemaVersion','gate','status','exitCode','startedAt','finishedAt',
    'durationSeconds','toolchain','metrics','artifacts','errors','warnings','commitSha'
}

if len(sys.argv) != 3:
    raise SystemExit('usage: validate_gate_result.py RESULT GATE')

p, expected_gate = sys.argv[1:]
with open(p, encoding='utf-8') as f:
    obj = json.load(f)

missing = REQUIRED - set(obj)
if missing:
    raise SystemExit(f'missing fields: {sorted(missing)}')
if obj['gate'] != expected_gate:
    raise SystemExit('gate mismatch')
if obj['status'] not in ALLOWED:
    raise SystemExit('invalid status')
if not isinstance(obj['exitCode'], int):
    raise SystemExit('exitCode must be int')
if not isinstance(obj['durationSeconds'], (int, float)) or obj['durationSeconds'] < 0:
    raise SystemExit('invalid durationSeconds')
for key in ('toolchain', 'metrics'):
    if not isinstance(obj[key], dict):
        raise SystemExit(f'{key} must be object')
for key in ('artifacts', 'errors', 'warnings'):
    if not isinstance(obj[key], list):
        raise SystemExit(f'{key} must be array')

expected_sha = os.environ.get('EXPECTED_COMMIT_SHA') or os.environ.get('GITHUB_SHA')
if expected_sha and obj['commitSha'] != expected_sha:
    raise SystemExit(f'commit mismatch: {obj["commitSha"]} != {expected_sha}')

for artifact in obj['artifacts']:
    if not isinstance(artifact, str) or not artifact.strip():
        raise SystemExit(f'invalid artifact path: {artifact!r}')
    if os.path.isabs(artifact) or artifact.startswith('../') or '/./' in artifact or '\\' in artifact:
        raise SystemExit(f'unsafe artifact path: {artifact!r}')

print(f'GATE_RESULT_SCHEMA_PASS {expected_gate}')
