#!/usr/bin/env bash
set -euo pipefail

ANDROID_ROOT="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}"
if [[ -z "$ANDROID_ROOT" ]]; then
  echo 'ANDROID_HOME/ANDROID_SDK_ROOT is required.' >&2
  exit 200
fi
SDKMANAGER="$ANDROID_ROOT/cmdline-tools/latest/bin/sdkmanager"
if [[ ! -x "$SDKMANAGER" ]]; then
  # Some hosted images expose sdkmanager under a versioned cmdline-tools dir.
  SDKMANAGER="$(find "$ANDROID_ROOT/cmdline-tools" -maxdepth 2 -type f -path '*/bin/sdkmanager' -print -quit 2>/dev/null || true)"
fi
[[ -x "$SDKMANAGER" ]] || { echo 'Android sdkmanager unavailable.' >&2; exit 200; }

# Keep installation bounded: a transient package mirror issue must return a gate result.
timeout --signal=TERM --kill-after=30s 12m "$SDKMANAGER" "platform-tools" "platforms;android-36" "build-tools;36.0.0" "ndk;28.2.13676358"

for p in \
  "$ANDROID_ROOT/platforms/android-36" \
  "$ANDROID_ROOT/build-tools/36.0.0" \
  "$ANDROID_ROOT/ndk/28.2.13676358"; do
  [[ -d "$p" ]] || { echo "Required Android SDK component missing after install: $p" >&2; exit 1; }
done

command -v adb >/dev/null 2>&1 || [[ -x "$ANDROID_ROOT/platform-tools/adb" ]] || { echo 'adb unavailable after Android SDK setup.' >&2; exit 1; }
echo 'ANDROID_SDK_BASELINE=PASS'
