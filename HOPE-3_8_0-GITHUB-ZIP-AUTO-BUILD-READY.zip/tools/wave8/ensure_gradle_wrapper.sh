#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
WRAPPER="$ROOT/android/gradle/wrapper/gradle-wrapper.jar"
EXPECTED="81a82aaea5abcc8ff68b3dfcb58b3c3c429378efd98e7433460610fecd7ae45f"
URL="https://services.gradle.org/distributions/gradle-8.13-wrapper.jar"
if [[ -f "$WRAPPER" ]] && [[ "$(sha256sum "$WRAPPER" | awk '{print $1}')" == "$EXPECTED" ]]; then
  echo "GRADLE_WRAPPER_HASH_PASS"; exit 0
fi
if ! command -v curl >/dev/null 2>&1; then echo "GRADLE_WRAPPER_MISMATCH_AND_CURL_MISSING" >&2; exit 201; fi
TMP="$WRAPPER.tmp"
trap 'rm -f "$TMP"' EXIT
if ! curl -fsSL --retry 3 --connect-timeout 10 --max-time 60 "$URL" -o "$TMP"; then
  echo "GRADLE_WRAPPER_DOWNLOAD_BLOCKED" >&2
  exit 201
fi
actual="$(sha256sum "$TMP" | awk '{print $1}')"
[[ "$actual" == "$EXPECTED" ]] || { echo "GRADLE_WRAPPER_CHECKSUM_MISMATCH" >&2; exit 1; }
chmod 0644 "$TMP"
mkdir -p "$(dirname "$WRAPPER")"
mv "$TMP" "$WRAPPER"
echo "GRADLE_WRAPPER_REFRESHED_AND_VERIFIED"
