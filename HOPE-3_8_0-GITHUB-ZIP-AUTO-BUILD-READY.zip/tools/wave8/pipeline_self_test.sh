#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"; TMP="$ROOT/artifacts/wave8-pipeline-self-test"; rm -rf "$TMP"; mkdir -p "$TMP/gates" "$TMP/logs"
export GITHUB_SHA="SELFTEST-SHA"; export GITHUB_RUN_ID="SELFTEST-RUN"
make_result(){ local g="$1" s="$2"; cat > "$TMP/gates/$g.json" <<JSON
{"schemaVersion":1,"gate":"$g","status":"$s","exitCode":0,"commitSha":"$GITHUB_SHA","workflowRunId":"$GITHUB_RUN_ID","startedAt":"2026-09-01T00:00:00Z","finishedAt":"2026-09-01T00:00:01Z","durationSeconds":1,"toolchain":{},"metrics":{},"artifacts":[] ,"errors":[],"warnings":[]}
JSON
}
for i in $(seq -w 1 18); do make_result "GATE-$i" PASS; done
mkdir -p "$TMP/release"; echo '{"knownDefects":false}' > "$TMP/release/P0P1-KNOWN-DEFECTS.json"
# seed score and run aggregator in the temp tree
python3 - "$TMP/summary" <<'PY'
import json,os,sys
os.makedirs(sys.argv[1],exist_ok=True)
json.dump({'minScore':100,'p0p1KnownDefects':False},open(os.path.join(sys.argv[1],'PRODUCT-GRADE-SCORECARD.json'),'w'))
PY
# Scenario baseline: GO
(cd "$ROOT" && python3 tools/wave8/final_aggregator.py "$TMP" >/dev/null || true)
python3 - "$TMP/summary/RELEASE-GO-NOGO.json" <<'PY'
import json,sys; assert json.load(open(sys.argv[1]))['decision']=='GO'
PY
# A: timeout one gate, others preserved
make_result GATE-01 TIMEOUT; (cd "$ROOT" && python3 tools/wave8/final_aggregator.py "$TMP" >/dev/null || true)
python3 - "$TMP/summary/WAVE8-CERTIFICATION.json" <<'PY'
import json,sys;o=json.load(open(sys.argv[1])); assert o['counts']['TIMEOUT']==1 and all(o['gates'][f'GATE-{i:02d}']['status']=='PASS' for i in range(2,19)); assert o['goNoGo']=='NO-GO'
PY
# B: failed gate
make_result GATE-02 FAIL; (cd "$ROOT" && python3 tools/wave8/final_aggregator.py "$TMP" >/dev/null || true)
python3 - "$TMP/summary/WAVE8-CERTIFICATION.json" <<'PY'
import json,sys;o=json.load(open(sys.argv[1])); assert o['counts']['FAIL']==1
PY
# C: resume/checkpoint validity
make_result GATE-01 PASS; export ARTIFACT_ROOT="$TMP"; (cd "$ROOT" && tools/wave8/checkpoint.sh GATE-01 >/dev/null)
# D: missing gate
rm "$TMP/gates/GATE-03.json"; (cd "$ROOT" && python3 tools/wave8/final_aggregator.py "$TMP" >/dev/null || true)
python3 - "$TMP/summary/WAVE8-CERTIFICATION.json" <<'PY'
import json,sys;o=json.load(open(sys.argv[1])); assert o['gates']['GATE-03']['status']=='ERROR' and o['goNoGo']=='NO-GO'
PY
# E: stale checkpoint rejected
make_result GATE-03 PASS; python3 - "$TMP/gates/GATE-04.json" <<'PY'
import json,sys;p=sys.argv[1];o=json.load(open(p));o['commitSha']='STALE';json.dump(o,open(p,'w'))
PY
export ARTIFACT_ROOT="$TMP"; if (cd "$ROOT" && tools/wave8/checkpoint.sh GATE-04 >/dev/null 2>&1); then echo 'STALE_CHECKPOINT_ACCEPTED' >&2; exit 1; fi
# Final artifact output must be generated
(cd "$ROOT" && python3 tools/wave8/final_aggregator.py "$TMP" >/dev/null || true)
test -s "$TMP/summary/WAVE8-CERTIFICATION.json"; test -s "$TMP/summary/WAVE8-CERTIFICATION.md"; test -s "$TMP/summary/RELEASE-GO-NOGO.json"
rm -rf "$TMP"
echo 'WAVE8_PIPELINE_SELF_TEST=PASS'
