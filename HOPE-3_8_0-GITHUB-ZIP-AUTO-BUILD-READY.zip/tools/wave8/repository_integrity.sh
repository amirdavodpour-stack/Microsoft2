#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"; cd "$ROOT"
required=(pubspec.yaml pubspec.lock l10n.yaml lib/main.dart android/app/build.gradle.kts backend/package.json backend/package-lock.json backend/openapi/openapi.yaml)
for f in "${required[@]}"; do test -e "$f" || { echo "missing required file: $f"; exit 1; }; done
broken=0; while IFS= read -r -d '' l; do [[ -e "$l" ]] || { echo "broken symlink: $l"; broken=1; }; done < <(find . -type l -print0); ((broken==0))
for f in $(find . -type f \( -name '*.json' -o -name '*.yaml' -o -name '*.yml' \) -not -path './.git/*' -not -path './build/*' -not -path './backend/node_modules/*'); do python3 - "$f" <<'PY'
import json,sys
p=sys.argv[1]
if p.endswith('.json'): json.load(open(p,encoding='utf-8'))
PY
done
find . -type f -perm /111 -print >/tmp/hope_execs.txt || true
# forbidden secrets/private keys
! grep -RInE --exclude-dir=.git --exclude='*.md' --exclude='*.lock' 'BEGIN (RSA|EC|OPENSSH|DSA) PRIVATE KEY|AKIA[0-9A-Z]{16}|gh[pousr]_[A-Za-z0-9]{20,}' . >/tmp/hope_forbidden_scan.txt || { cat /tmp/hope_forbidden_scan.txt; exit 1; }
echo 'Repository integrity PASS'
