#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
cd "$ROOT"
WF=.github/workflows/wave8-certification.yml
for f in "$WF" .github/workflows/main.yml .github/workflows/production-release.yml .github/workflows/device-integration.yml; do test -s "$f"; done
python3 - "$WF" <<'PY'
import re,sys
p=sys.argv[1]; s=open(p,encoding='utf-8').read()
jobs=re.findall(r'^  (gate\d{2}):\n(.*?)(?=^  gate\d{2}:\n|\Z)',s,re.M|re.S)
assert [j[0] for j in jobs]==[f'gate{i:02d}' for i in range(1,19)], 'Wave8 must contain exactly gates 01-18'
for jid,b in jobs[:17]:
    assert 'timeout-minutes:' in b, f'{jid} missing job timeout'
    assert 'actions/cache/restore@' in b, f'{jid} missing checkpoint restore'
    assert 'actions/cache/save@' in b, f'{jid} missing checkpoint save'
    assert 'restore_checkpoint.sh' in b, f'{jid} missing reusable-checkpoint validation'
    assert "steps.reusable-checkpoint.outputs.reuse != 'true'" in b, f'{jid} does not gate rerun on reusable PASS'
assert 'steps.reusable-checkpoint.outputs.reuse != \'true\'' in re.search(r'^  gate10:\n(.*?)(?=^  gate11:)',s,re.M|re.S).group(1)
assert 'Ensure GATE-10 checkpoint after emulator action failure' not in s
assert "ensure_gate_result.sh GATE-10" in s
assert 'cp -r ../artifacts/release-evidence/.' in s
print('WAVE8_PIPELINE_STRUCTURE_PASS')
PY
bash -n tools/wave8/*.sh
ruby -e 'require "yaml"; ARGV.each{|f| YAML.load_file(f, aliases:true)}' .github/workflows/*.yml >/dev/null
python3 -m py_compile tools/wave8/final_aggregator.py tools/wave8/score_from_evidence.py
