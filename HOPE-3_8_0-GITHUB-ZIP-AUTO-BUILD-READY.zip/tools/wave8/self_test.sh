#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
TMP="$ROOT/artifacts/wave8-self-test"
rm -rf "$TMP"; mkdir -p "$TMP"
export ARTIFACT_ROOT="$TMP"
run() { local gate="$1" t="$2" cmd="$3"; set +e; tools/wave8/run_gate.sh "$gate" "$cmd" "$t" >/dev/null 2>&1; rc=$?; set -e; echo "$gate rc=$rc status=$(python3 -c 'import json,sys; print(json.load(open(sys.argv[1]))["status"])' "$TMP/gates/$gate.json")"; }
run GATE-TIMEOUT 1 'sleep 3'
run GATE-FAIL 10 'exit 1'
run GATE-PASS 10 'printf ok'
[[ "$(python3 -c 'import json; print(json.load(open("'"$TMP"'/gates/GATE-TIMEOUT.json"))["status"])')" == TIMEOUT ]]
[[ "$(python3 -c 'import json; print(json.load(open("'"$TMP"'/gates/GATE-FAIL.json"))["status"])')" == FAIL ]]
[[ "$(python3 -c 'import json; print(json.load(open("'"$TMP"'/gates/GATE-PASS.json"))["status"])')" == PASS ]]
# Stale checkpoint must be rejected.
python3 - "$TMP/gates/GATE-PASS.json" <<'PY'
import json,sys
p=sys.argv[1]; o=json.load(open(p)); o['commitSha']='STALE'; json.dump(o,open(p,'w'))
PY
if tools/wave8/checkpoint.sh GATE-PASS >/dev/null 2>&1; then echo 'stale checkpoint unexpectedly accepted' >&2; exit 1; fi
# Preservation check: all prior results remain after timeout/failure.
test -s "$TMP/gates/GATE-TIMEOUT.json"; test -s "$TMP/gates/GATE-FAIL.json"; test -s "$TMP/gates/GATE-PASS.json"
rm -rf "$TMP"
echo 'WAVE8_SELF_TEST=PASS'
