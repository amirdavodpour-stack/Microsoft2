#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
out="${1:?output required}"
mkdir -p "$(dirname "$out")"
{
  echo "timestamp=$(date -u +%Y-%m-%dT%H:%M:%SZ)"
  echo "git_sha=$(git -C "$ROOT" rev-parse HEAD 2>/dev/null || echo UNKNOWN)"
  echo "runner=${RUNNER_OS:-local}"
  echo "node=$(node --version 2>/dev/null || echo unavailable)"
  echo "npm=$(npm --version 2>/dev/null || echo unavailable)"
  echo "flutter=$(flutter --version 2>/dev/null | head -n1 || echo unavailable)"
  echo "dart=$(dart --version 2>&1 | head -n1 || echo unavailable)"
  echo "java=$(java -version 2>&1 | head -n1 || echo unavailable)"
  echo "python=$(python3 --version 2>/dev/null || echo unavailable)"
  echo "os=$(uname -a)"
  free -h || true
  df -h "$ROOT" || true
} > "$out"
