#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
count=0
while IFS= read -r -d '' file; do
  node --check "$file"
  count=$((count+1))
done < <(find backend/src backend/tools backend/tests tools -type f \( -name '*.js' -o -name '*.mjs' \) -print0 | sort -z)
printf 'Node syntax PASS: %s files checked\n' "$count"
