#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
if [[ ! -s pubspec.lock ]]; then
  echo "PUBSPEC_LOCK_MISSING" >&2
  exit 200
fi
python3 - <<'PY'
from pathlib import Path
text=Path('pubspec.lock').read_text(encoding='utf-8')
if 'packages:' not in text or 'sdks:' not in text:
    raise SystemExit('PUBSPEC_LOCK_MALFORMED')
print('PUBSPEC_LOCK_POLICY_PASS')
PY
