#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
python3 - <<'PY'
from pathlib import Path
import re, sys
try:
    import yaml
except Exception as e:
    print(f'ERROR: PyYAML is required for workflow syntax validation: {e}', file=sys.stderr)
    raise SystemExit(1)
root=Path('.github/workflows')
files=sorted(root.glob('*.yml')) + sorted(root.glob('*.yaml'))
if not files:
    raise SystemExit('ERROR: no GitHub workflow files found')
for f in files:
    data=yaml.safe_load(f.read_text())
    if not isinstance(data, dict):
        raise SystemExit(f'ERROR: {f} is not a YAML mapping')
    if 'jobs' not in data or not isinstance(data['jobs'], dict) or not data['jobs']:
        raise SystemExit(f'ERROR: {f} has no jobs')
    for m in re.finditer(r'\buses:\s*([^\s#]+)', f.read_text()):
        ref=m.group(1)
        if ref.startswith('./'):
            continue
        if '@' not in ref or not re.fullmatch(r'[^@\s]+@[0-9a-fA-F]{40}', ref):
            raise SystemExit(f'ERROR: non-immutable action ref in {f}: {ref}')
print(f'CI hygiene PASS: {len(files)} workflow files parsed; action refs pinned to 40-char SHAs')
PY
