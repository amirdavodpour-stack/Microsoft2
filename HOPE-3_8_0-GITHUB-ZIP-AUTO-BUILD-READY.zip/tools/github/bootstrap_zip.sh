#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
cd "$ROOT"

archive="${ARCHIVE_INPUT:-}"
if [[ -n "$archive" ]]; then
  archive="${archive#./}"
  test -f "$archive" || { echo "Archive not found: $archive" >&2; exit 1; }
else
  mapfile -t zips < <(find . -maxdepth 1 -type f -iname '*.zip' -printf '%T@ %p\n' | sort -nr | cut -d' ' -f2-)
  if [[ ${#zips[@]} -eq 0 ]]; then
    echo 'No ZIP archive found in repository root.' >&2
    exit 1
  fi
  archive="${zips[0]#./}"
fi

echo "Using archive: $archive"
python3 - "$archive" "$TMP/extracted" <<'PY'
import sys, zipfile
from pathlib import Path
archive = Path(sys.argv[1])
out = Path(sys.argv[2])
out.mkdir(parents=True, exist_ok=True)
with zipfile.ZipFile(archive) as z:
    for info in z.infolist():
        name = info.filename.replace('\\', '/')
        p = Path(name)
        if p.is_absolute() or '..' in p.parts:
            raise SystemExit(f'Unsafe ZIP path rejected: {name}')
    z.extractall(out)
PY

project_root=""
while IFS= read -r pub; do
  d="$(dirname "$pub")"
  if [[ -f "$d/android/gradlew" && -d "$d/lib" ]]; then
    project_root="$d"
    break
  fi
done < <(find "$TMP/extracted" -type f -name pubspec.yaml -print | sort)

if [[ -z "$project_root" ]]; then
  echo 'Could not locate a Flutter project root inside the ZIP.' >&2
  find "$TMP/extracted" -maxdepth 3 -type f | head -100 >&2
  exit 1
fi

echo "Detected project root: $project_root"

# Preserve Git metadata and this bootstrap process, replace repository payload.
shopt -s dotglob nullglob
for entry in "$ROOT"/* "$ROOT"/.[!.]* "$ROOT"/..?*; do
  [[ "$entry" == "$ROOT/.git" ]] && continue
  [[ "$entry" == "$ROOT/.github/workflows/zip-bootstrap.yml" ]] && continue
  rm -rf "$entry"
done

cp -a "$project_root"/. "$ROOT/"
mkdir -p "$ROOT/.github/workflows"
# Keep the bootstrap workflow permanently available for future ZIP re-bootstrap.
cat > "$ROOT/.github/workflows/zip-bootstrap.yml" <<'YAML'
name: HOPE ZIP Bootstrap
on:
  workflow_dispatch:
    inputs:
      archive:
        description: 'ZIP filename in repository (leave blank to auto-detect)'
        required: false
        type: string
permissions:
  contents: write
concurrency:
  group: hope-zip-bootstrap-${{ github.ref }}
  cancel-in-progress: false
env:
  FLUTTER_VERSION: '3.47.0'
jobs:
  bootstrap:
    runs-on: ubuntu-24.04
    timeout-minutes: 30
    steps:
      - name: Checkout repository
        uses: actions/checkout@de0fac2e4500dabe0009e67214ff5f5447ce83dd # v6.0.2
        with:
          fetch-depth: 1
          persist-credentials: true
      - name: Setup Java 17
        uses: actions/setup-java@b6effb05e454b25005698d916606bdc6ffcbf961 # v5.7.0
        with:
          distribution: temurin
          java-version: '17'
      - name: Setup Flutter
        uses: subosito/flutter-action@1a449444c387b1966244ae4d4f8c696479add0b2 # v2.23.0
        with:
          flutter-version: ${{ env.FLUTTER_VERSION }}
          channel: stable
          cache: true
      - name: Extract ZIP into repository root
        env:
          ARCHIVE_INPUT: ${{ inputs.archive }}
        run: ./tools/github/bootstrap_zip.sh
      - name: Generate or validate pubspec.lock
        run: |
          set -euo pipefail
          if [ -f pubspec.lock ]; then flutter pub get --enforce-lockfile; else flutter pub get; fi
          test -s pubspec.lock
      - name: Commit extracted project and lockfile
        run: |
          set -euo pipefail
          git config user.name 'github-actions[bot]'
          git config user.email '41898282+github-actions[bot]@users.noreply.github.com'
          git add -A
          git rm -f --ignore-unmatch -- '*.zip' '*.ZIP' || true
          if ! git diff --cached --quiet; then
            git commit -m 'chore: bootstrap HOPE project from ZIP'
            git push
          fi
YAML

rm -f -- "$archive"
echo 'ZIP extraction/bootstrap completed.'
