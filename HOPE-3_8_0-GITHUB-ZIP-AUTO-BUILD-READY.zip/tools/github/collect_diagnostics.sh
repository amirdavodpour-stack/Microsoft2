#!/usr/bin/env bash
set +e
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
cd "$ROOT"
mkdir -p artifacts/diagnostics
{
  echo '--- date ---'; date -u
  echo '--- uname ---'; uname -a
  echo '--- disk ---'; df -h
  echo '--- memory ---'; free -h || true
  echo '--- cpu ---'; nproc || true
  echo '--- git ---'; git rev-parse HEAD 2>/dev/null || true
  echo '--- flutter ---'; flutter --version 2>&1 || true
  echo '--- dart ---'; dart --version 2>&1 || true
  echo '--- java ---'; java -version 2>&1 || true
  echo '--- node ---'; node --version 2>&1 || true
  echo '--- gradle ---'; ./android/gradlew --version 2>&1 || true
} > artifacts/diagnostics/environment.txt
for f in logs/*.log; do
  [ -f "$f" ] || continue
  echo "===== $f (last 300 lines) =====" >> artifacts/diagnostics/failure-tail.log
  tail -n 300 "$f" >> artifacts/diagnostics/failure-tail.log
  echo >> artifacts/diagnostics/failure-tail.log
done
