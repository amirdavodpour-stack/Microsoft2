import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:integration_test/integration_test.dart';
import 'package:provider/provider.dart';

import 'package:hope_mobile/core/auth/auth_controller.dart';
import 'package:hope_mobile/core/network/api_client.dart';
import 'package:hope_mobile/core/settings/settings_controller.dart';
import 'package:hope_mobile/core/storage/secure_store.dart';
import 'package:hope_mobile/core/theme/theme_controller.dart';
import 'package:hope_mobile/main.dart';

void main() {
  IntegrationTestWidgetsFlutterBinding.ensureInitialized();

  testWidgets(
    'HOPE boots on a real device surface',
    (tester) async {
      final configuredBaseUrl = const String.fromEnvironment(
        'API_BASE_URL',
        defaultValue: 'http://10.0.2.2:9/api/v1',
      );
      final store = SecureStore();
      final api = ApiClient(store, baseUrl: configuredBaseUrl);
      final settings = HopeSettingsController();
      await settings.load();
      final auth = AuthController(api, store);
      await auth.restoreSession();
      await tester.pumpWidget(
        MultiProvider(
          providers: [
            ChangeNotifierProvider.value(value: settings),
            ChangeNotifierProvider(
              create: (_) => ThemeController(settings),
            ),
            ChangeNotifierProvider.value(value: auth),
          ],
          child: WorkMarketplaceApp(api: api),
        ),
      );
      await tester.pump(const Duration(milliseconds: 500));
      expect(find.byType(MaterialApp), findsOneWidget);
      expect(
        find.bySemanticsLabel('HOPE').evaluate().isNotEmpty ||
            find.text('HOPE').evaluate().isNotEmpty,
        isTrue,
      );
    },
    timeout: const Timeout(Duration(minutes: 2)),
  );

  testWidgets(
    'staging live endpoint is reachable in CI device certification',
    (tester) async {
      const enabled = bool.fromEnvironment(
        'CI_DEVICE_INTEGRATION',
        defaultValue: false,
      );
      if (!enabled) return;

      const baseUrl = String.fromEnvironment('API_BASE_URL', defaultValue: '');
      expect(baseUrl, isNotEmpty);
      expect(Uri.parse(baseUrl).scheme, 'https');

      final response = await http
          .get(Uri.parse('$baseUrl/live'))
          .timeout(const Duration(seconds: 30));
      expect(response.statusCode, 200);
      expect(
        response.headers['content-type'] ?? '',
        contains('application/json'),
      );

      final categories = await http
          .get(Uri.parse('$baseUrl/categories'))
          .timeout(const Duration(seconds: 30));
      expect(categories.statusCode, 200);
      expect(
        categories.headers['content-type'] ?? '',
        contains('application/json'),
      );
      final decoded = jsonDecode(categories.body);
      expect(decoded, isA<Map>());
      expect((decoded['data'] as List).length, greaterThanOrEqualTo(10));

      // Runtime auth/session certification: exercise registration, an
      // authenticated endpoint, refresh-token rotation, and the persisted
      // session path from the same Android process that the app uses.
      final stamp = DateTime.now().microsecondsSinceEpoch;
      final email = 'device-cert-$stamp@example.invalid';
      const password = 'DeviceCert-Aa1!2345';
      final register = await http
          .post(
            Uri.parse('$baseUrl/auth/register'),
            headers: const {'Content-Type': 'application/json'},
            body: jsonEncode({
              'email': email,
              'password': password,
              'displayName': 'Device Certification',
            }),
          )
          .timeout(const Duration(seconds: 30));
      expect(register.statusCode, 201);
      final authBody = jsonDecode(register.body) as Map<String, dynamic>;
      final authData = authBody['data'] as Map<String, dynamic>;
      final accessToken = authData['accessToken'] as String;
      final refreshToken = authData['refreshToken'] as String;
      expect(accessToken, isNotEmpty);
      expect(refreshToken, isNotEmpty);

      final providerMe = await http
          .get(
            Uri.parse('$baseUrl/providers/me'),
            headers: {'Authorization': 'Bearer $accessToken'},
          )
          .timeout(const Duration(seconds: 30));
      // New accounts may not yet have a provider profile; either a valid
      // resource response or the documented not-found response is acceptable.
      expect(<int>[200, 404], contains(providerMe.statusCode));

      final refresh = await http
          .post(
            Uri.parse('$baseUrl/auth/refresh'),
            headers: const {'Content-Type': 'application/json'},
            body: jsonEncode({'refreshToken': refreshToken}),
          )
          .timeout(const Duration(seconds: 30));
      expect(refresh.statusCode, 200);
      final refreshBody = jsonDecode(refresh.body) as Map<String, dynamic>;
      final refreshData = refreshBody['data'] as Map<String, dynamic>;
      expect(refreshData['accessToken'], isA<String>());
      expect(refreshData['refreshToken'], isA<String>());
      expect(refreshData['refreshToken'], isNot(equals(refreshToken)));
    },
    timeout: const Timeout(Duration(minutes: 4)),
  );
}
