import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/auth/auth_controller.dart';
import '../../core/network/api_client.dart';
import '../../core/ui/components.dart';
import '../../theme/app_theme.dart';

class WalletPage extends StatefulWidget {
  const WalletPage({super.key, required this.api});
  final ApiClient api;
  @override State<WalletPage> createState() => _WalletPageState();
}

class _WalletPageState extends State<WalletPage> {
  Future<dynamic>? _future;
  @override void didChangeDependencies() {
    super.didChangeDependencies();
    if (_future == null && !context.read<AuthController>().isGuest) {
      _future = widget.api.request('GET', '/jobs/mine', auth: true);
    }
  }
  @override Widget build(BuildContext context) {
    final auth = context.watch<AuthController>();
    if (auth.isGuest) {
      return const Center(child: EmptyState(
        icon: Icons.account_balance_wallet_outlined,
        title: 'ورود لازم است',
        message: 'برای مشاهده کیف پول و وضعیت پرداخت‌ها وارد حساب شوید.',
      ));
    }
    return RefreshIndicator(
      onRefresh: () async { setState(() => _future = widget.api.request('GET','/jobs/mine',auth:true)); await _future!.catchError((_) {}); },
      child: ListView(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.fromLTRB(20, 12, 20, 100),
        children: [
          Text('کیف پول', style: Theme.of(context).textTheme.displaySmall),
          const SizedBox(height: 4),
          Text('وضعیت مالی و پرداخت‌های شما در یک نگاه.', style: Theme.of(context).textTheme.bodyLarge),
          const SizedBox(height: 18),
          HopeSurface(
            highlight: true, padding: const EdgeInsets.all(20),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('موجودی کل', style: Theme.of(context).textTheme.bodyMedium),
              const SizedBox(height: 6),
              Text('— تومان', style: Theme.of(context).textTheme.headlineSmall),
              const SizedBox(height: 4),
              Text('موجودی پس از تأیید تراکنش‌ها به‌روز می‌شود.', style: Theme.of(context).textTheme.bodyMedium),
              const SizedBox(height: 16),
              Row(children: [
                Expanded(child: FilledButton.icon(onPressed: () => _showAction(context, 'واریز'), icon: const Icon(Icons.add_rounded), label: const Text('واریز'))),
                const SizedBox(width: 10),
                Expanded(child: OutlinedButton.icon(onPressed: () => _showAction(context, 'برداشت'), icon: const Icon(Icons.arrow_upward_rounded), label: const Text('برداشت'))),
              ])
            ]),
          ),
          const SizedBox(height: 14),
          Row(children: [
            Expanded(child: _balance(context, 'قابل برداشت', '—')),
            const SizedBox(width: 10),
            Expanded(child: _balance(context, 'در انتظار', '—')),
          ]),
          const SizedBox(height: 10),
          _balance(context, 'رزرو شده', '—'),
          const SizedBox(height: 22),
          Text('آخرین فعالیت مالی', style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 10),
          FutureBuilder<dynamic>(
            future: _future,
            builder: (context, snap) {
              final list = snap.data is List ? (snap.data as List) : const [];
              if (snap.connectionState != ConnectionState.done) return const Padding(padding: EdgeInsets.all(30), child: Center(child: CircularProgressIndicator()));
              if (list.isEmpty) return const EmptyState(icon: Icons.receipt_long_outlined, title: 'هنوز تراکنشی نیست', message: 'پس از انجام فعالیت مالی، اینجا نمایش داده می‌شود.');
              return Column(children: list.take(5).map<Widget>((raw) {
                final m = raw is Map ? raw : const {};
                return Padding(padding: const EdgeInsets.only(bottom: 8), child: HopeSurface(padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10), child: ListTile(
                  contentPadding: EdgeInsets.zero, leading: const HopeIconTile(Icons.payments_outlined),
                  title: Text('${m['title'] ?? 'فعالیت کاری'}', maxLines: 1, overflow: TextOverflow.ellipsis),
                  subtitle: Text('${m['status'] ?? 'در جریان'}'),
                  trailing: Text('${m['amount'] ?? '—'}'),
                )));
              }).toList());
            },
          )
        ],
      ),
    );
  }

  Widget _balance(BuildContext context, String label, String value) => HopeSurface(
    padding: const EdgeInsets.all(15), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(label, style: Theme.of(context).textTheme.bodyMedium),
      const SizedBox(height: 5), Text('$value تومان', style: Theme.of(context).textTheme.titleLarge),
    ]),
  );

  void _showAction(BuildContext context, String action) {
    showModalBottomSheet<void>(context: context, showDragHandle: true, builder: (_) => SafeArea(
      child: Padding(padding: const EdgeInsets.fromLTRB(22, 6, 22, 28), child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Text(action, style: Theme.of(context).textTheme.headlineSmall),
        const SizedBox(height: 8),
        Text('این بخش به سرویس پرداخت متصل است و پیش از تأیید، مبلغ، کارمزد و مبلغ نهایی را شفاف نمایش می‌دهد.', style: Theme.of(context).textTheme.bodyMedium),
        const SizedBox(height: 18),
        FilledButton(onPressed: () => Navigator.pop(context), child: const Text('متوجه شدم')),
      ]),
    ));
  }
}
