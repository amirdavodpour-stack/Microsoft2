# HOPE 3.8.0 — Security Threat Model

## Scope
HOPE mobile application, Node.js API, PostgreSQL, object storage, payment/notification providers and CI/CD release pipeline.

## Security lifecycle
This model follows Microsoft SDL principles across requirements, design, implementation, verification, release and response. It is maintained with each material architecture or trust-boundary change.

## Trust boundaries
1. Mobile device ↔ public API
2. Public API ↔ PostgreSQL
3. Public API ↔ S3-compatible storage
4. Outbox worker ↔ payment/notification providers
5. GitHub Actions ↔ release artifacts and signing material
6. Administrators ↔ privileged API routes

## High-risk threats and mitigations
| Threat | Class | Mitigation | Evidence |
|---|---|---|---|
| Credential theft | Spoofing | PBKDF2, secure token storage, short access TTL, refresh rotation | security tests |
| Token forgery | Tampering | HS256 header validation, signature verification, issuer/audience checks, session version | JWT contracts |
| Token key rotation failure | Spoofing | current + previous signing secret window | runtime rotation test |
| IDOR/BOLA | Elevation | participant/owner/admin checks at route boundary | authorization tests |
| Replay/idempotency | Tampering | idempotency keys + unique DB constraints | provider contracts |
| Notification duplication | Tampering | atomic per-user dedupe constraint | notification tests |
| Sensitive log disclosure | Information disclosure | centralized log redaction | logging contract |
| Object upload abuse | Tampering/DoS | allowlisted MIME, size, upload intents, provider validation | storage tests |
| Secret leakage in CI | Information disclosure | masked environment, pinned actions, secret scanning, CodeQL/Scorecard | CI evidence |
| Supply-chain compromise | Tampering | lockfiles, action pinning, SBOM, provenance, release manifest | release evidence |
| Database corruption | Tampering/DoS | transactions, constraints, backup/restore verification | DR gate |

## Required residual-risk tests
- real staging authorization matrix
- secret rotation without logout
- PostgreSQL failover and rollback
- object-storage outage and compensation
- provider timeout/replay sequences
- mobile tamper/resilience verification
