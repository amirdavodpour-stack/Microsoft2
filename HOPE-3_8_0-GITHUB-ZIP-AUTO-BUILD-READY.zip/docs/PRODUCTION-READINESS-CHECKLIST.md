# HOPE 3.8.0 Production Readiness Checklist

This checklist is evidence-driven. A missing runtime environment must be reported as blocked, never as pass.

## Source reproducibility
- [ ] `pubspec.lock` is committed and passes `tools/verify-pubspec-lock-fresh.sh`.
- [ ] `backend/package-lock.json` is committed and npm CI is clean.
- [ ] `.flutter-version`, `toolchain.yaml`, Android/Gradle pins and CI pins agree.
- [ ] Gradle 8.13 distribution checksum and wrapper JAR checksum match official Gradle release checksums.

## Mobile runtime
- [ ] `flutter analyze` passes on Flutter 3.47.0.
- [ ] `flutter test --coverage` passes.
- [ ] Release APK builds with the intended `API_BASE_URL`.
- [ ] `aapt`/`apkanalyzer` metadata matches package/version.
- [ ] Production signing is verified with `apksigner`.
- [ ] Emulator smoke passes on the pinned API image.

## Backend runtime
- [ ] Node 24 exact runtime recorded.
- [ ] PostgreSQL schema/bootstrap/restore evidence exists.
- [ ] Storage/provider/payment/notification staging certification exists.
- [ ] Performance p50/p95/p99 and timeout/error budgets are within policy.

## Release decision
A release is GO only when all mandatory gates are PASS, evidence is complete, and no P0/P1 defect or unresolved blocker exists.

## PostgreSQL runtime integrity hardening
- [ ] Production routes must not mutate `db.collection` when `DATABASE_URL` is configured; repository/SQL methods are authoritative.
- [ ] PostgreSQL bootstrap row count and duration are monitored; large in-memory compatibility state is treated as a scaling warning.
- [ ] Pool connections use bounded connection, lock, and statement timeouts.
