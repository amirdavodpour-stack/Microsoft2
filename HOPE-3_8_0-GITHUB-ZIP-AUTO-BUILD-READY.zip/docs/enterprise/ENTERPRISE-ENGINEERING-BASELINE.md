# HOPE Enterprise Engineering Baseline

## Control families

| Family | Baseline | Evidence |
|---|---|---|
| Secure SDLC | NIST SP 800-218 SSDF | security + CI gates |
| Web/API Security | OWASP ASVS 5.0.0 | API/security tests |
| Mobile Security | OWASP MASVS | Android/static/runtime gates |
| Supply Chain | SLSA v1.2 + artifact attestations | provenance + manifest |
| Quality | deterministic tests + fail-closed gates | Wave 8 evidence |
| Reliability | bounded timeouts + retry/idempotency | resilience/perf gates |
| Release | immutable tag + signed/provenance evidence | production workflow |

## Non-negotiable rules

1. No fabricated PASS.
2. No stale evidence may satisfy a new commit.
3. No credential appears in logs/artifacts.
4. Runtime-unavailable gates are BLOCKED, never PASS.
5. Production release requires a real Flutter lockfile.
6. Production release must be traceable to one Git SHA and one build provenance record.
