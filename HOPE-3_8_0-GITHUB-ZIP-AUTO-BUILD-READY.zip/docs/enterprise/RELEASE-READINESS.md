# HOPE 3.8.0 — Release Readiness Checklist

## Code
- [ ] peer review / separation of duties
- [ ] no known P0/P1
- [ ] threat model reviewed
- [ ] static analysis clean

## Dependencies
- [ ] backend package-lock committed
- [ ] Flutter pubspec.lock committed
- [ ] vulnerability review complete
- [ ] dependency licenses reviewed

## Build
- [ ] Flutter version pinned
- [ ] JDK pinned
- [ ] Gradle pinned and wrapper integrity verified
- [ ] Android SDK/NDK pinned
- [ ] reproducible release metadata captured

## Runtime
- [ ] unit/widget/integration tests pass
- [ ] staging smoke pass
- [ ] payment/notification/storage staging pass
- [ ] backup/restore pass
- [ ] bounded performance pass

## Release
- [ ] SBOM
- [ ] provenance
- [ ] SHA-256 manifest
- [ ] signing verification
- [ ] APK install/launch verification
- [ ] GO/NO-GO generated from evidence

## Operations
- [ ] SLOs configured
- [ ] alert routing verified
- [ ] rollback procedure exercised
- [ ] incident runbook available
